---
name: java-source-sink-audit
description: 审计 Java 代码库，定位本技能明确定义的 sink 点（SNK-1 类加载：Class.forName / ClassLoader.loadClass / URLClassLoader / defineClass；SNK-2 JDBC 连接 DriverManager.getConnection/connect；SNK-3 反序列化：ObjectInputStream.readObject / XMLDecoder / Kryo / Hessian 等触发类加载的过程；SNK-4 工作流引擎（Activiti/Flowable/Camunda）表达式与脚本执行：Expression.getValue / ScriptTaskActivityBehavior / delegateExpression / createDeployment 等；SNK-5 YAML 反序列化（YamlBeans）：YamlReader.read / YamlConfig；SNK-6 XStream 反序列化：fromXML；SNK-7 Kafka 客户端反序列化与类加载：Deserializer 配置类名 / 自定义反序列化器调用 ObjectInputStream；SNK-8 Groovy 脚本执行：GroovyShell.evaluate / GroovyClassLoader.parseClass / GStringTemplateEngine；SNK-9 Thymeleaf 模板渲染与表达式注入（SSTI）：视图名注入 / TemplateEngine.process / __${...}__）与 source 点（SRC-1 任意后缀文件上传落盘、SRC-2 getResourceAsStream 使用、SRC-3 URL 对象未强制转换 HttpURLConnection 却调用 openStream/getInputStream 的 SSRF 入口、SRC-4 RandomAccessFile/ZipFile/JarFile 缓存不关闭导致的文件描述符泄漏），并对每个命中点做污点分析：从终点反向回溯完整调用链（谁调用了它、参数从哪来、经过哪些传播与净化），输出"文件路径+行号+污点路径链+置信度+净化状态+危险级别"的结构化报告。**范围外的一切漏洞类型（如 JNDI 注入、SQL 注入、命令注入、XSS、CSRF、硬编码凭据、弱加密、不经本技能列出的组件入口的裸 SpEL/EL/模板注入等）一律不检索、不报告，即使代码中存在。** 凡用户要求查找/检索/审计代码中的 sink 点、source 点、漏洞触发点、污染源、污点分析、数据流分析、调用链、谁调用了这个方法、参数从哪来、Class.forName、ClassLoader.loadClass、URLClassLoader、反序列化、ObjectInputStream、readObject、XMLDecoder、XStream、Kryo、Hessian、JDBC 连接串、任意文件上传、getResourceAsStream、URL/SSRF 相关危险调用、RandomAccessFile、ZipFile、JarFile、fd/文件描述符泄漏、工作流引擎（Activiti/Flowable/Camunda）表达式或脚本注入、YamlBeans、Groovy 脚本执行、GroovyShell、Thymeleaf SSTI/模板注入、Kafka 反序列化/类加载配置，或要求给出带文件位置、路径与危险分级的漏洞清单时，都必须使用本技能，即使他们没有明确说出"sink/source"这类术语。
---

# Java Source-Sink 审计（含污点分析）

## 这个技能做什么

对一个 Java 代码库做**漏洞 sink 点 + source 点检索 + 污点分析**，产出结构化审计报告。它做**跨方法、跨文件、跨类的调用链追踪**：不仅定位 13 类规则命中点，还像安全审计员一样回答"这个危险调用是否真的能被外部输入到达？中间经过了哪些传递？有没有校验？"

**核心问题**：每个终点命中点，是否存在一条从"不可信输入入口"到"终点"的数据流路径？存在则报告完整路径链；不存在（常量/固定值）则如实说明。

**本技能只做一件事：按下方"检查规则"逐条检索并做污点分析，不做任何范围外审计。**

## 范围边界（重要，必须遵守）

- 本技能覆盖**且仅覆盖**以下 13 类规则：SNK-1、SNK-2、SNK-3、SNK-4、SNK-5、SNK-6、SNK-7、SNK-8、SNK-9、SRC-1、SRC-2、SRC-3、SRC-4。
- **禁止**检索、报告或"顺带提示"任何范围外的问题，即使代码中明显存在，包括但不限于：
  - JNDI 注入（`InitialContext.lookup` 等）
  - **不经本技能列出的组件入口的**通用表达式/模板注入（如裸 `javax.el` EL、裸 `@Value` SpEL、Freemarker/Velocity 等未列入 SNK-4/8/9 的引擎）——注意：经由 SNK-4（工作流引擎）、SNK-8（Groovy）、SNK-9（Thymeleaf）具体组件入口的表达式/脚本/模板注入**在范围内**
  - SQL 注入、命令注入、文件包含/读取（非上述规则路径）
  - XSS、CSRF、SSRF 变体外的其它请求伪造
  - 硬编码凭据、弱加密、`useSSL=false` 等配置卫生问题
  - 资源未关闭（除 SRC-4 列出的 RandomAccessFile/ZipFile/JarFile 缓存场景之外的一般性问题）
  - 反序列化**之外**的其它数据解析类问题（如 XML 解析攻击、正则注入——注意：反序列化本身属于 SNK-3/SNK-5/SNK-6/SNK-7，在范围内）
- 报告**不得**出现"附加发现""其他问题""顺带提示"等章节；发现范围外问题时，要么忽略，要么仅在不影响报告聚焦的前提下标注"不在本技能范围"（不超过一行，不展开）。
- **污点路径链的中间节点**即使涉及范围外操作（如链路中途经过 JNDI lookup），也只作为"传递节点"出现（标注"传递经过 文件:行号，不评价"），**不展开分析、不列为发现**。
- 如果用户明确要求扩展范围（如"顺便看看 JNDI"），才可追加，并在报告开头注明"本次为范围扩展审计"。

## 检查规则

### Sink 点

**SNK-1: 类加载（Class.forName / ClassLoader.loadClass / URLClassLoader / defineClass）**
- 检索：`Class.forName(`（含三参变体）、`ClassLoader.loadClass(`（含 `URLClassLoader.loadClass`）、`new URLClassLoader(`、`defineClass(` 的所有出现。
- 为什么危险：四类调用都会触发**类加载**，加载的类名或类字节若受攻击者控制：
  - `Class.forName(name)` / `Class.forName(name, initialize, loader)`：加载任意类并（initialize=true 时）执行静态初始化代码 → 潜在 RCE；
  - `ClassLoader.loadClass(name)` / `URLClassLoader.loadClass(name)`：加载任意类；配合 `URLClassLoader(URLs)` 且 URL 受控时可从攻击者指定的远程 jar 加载类 → 远程类加载 RCE；
  - `defineClass(byte[])`：直接定义类字节，字节受控时等价于注入任意字节码 → RCE 原语。
- 分级：
  - **High**：类名字符串或加载来源（URL 列表、类字节）来自不可信输入（HTTP 参数、请求体、上传内容、远程 URL 等），无白名单。
  - **Medium**：类名/来源来自数据库、配置文件等半可信来源，或仅有黑名单/前缀校验（可绕过）。
  - **Info**：常量类名或固定本地类路径（如 `loadClass("com.mysql.cj.jdbc.Driver")`、固定本地目录的 URLClassLoader）—— 正常插件加载，记录但不当作漏洞。

**SNK-2: JDBC 连接（DriverManager.getConnection / connect）**
- 检索：`DriverManager.getConnection(`、`DriverManager.connect(`、`java.sql.DriverManager` 的所有使用。
- 为什么危险：JDBC URL 若受攻击者控制，可连接攻击者指定的数据库（MySQL/PostgreSQL 假服务器）或内网地址，配合 URL 中的 `autoDeserialize=true`、H2/HSQLDB 内存库等触发服务端反序列化/任意类加载 → RCE；也是 SSRF 的一类。
- 分级：
  - **High**：JDBC URL 来自不可信输入。
  - **Medium**：URL 拼接自半可信来源（如用户输入拼前缀），或仅校验了前缀（`startsWith("jdbc:mysql")`）可绕过。
  - **Info**：URL 为固定常量/来自可信配置。

**SNK-3: 反序列化（ObjectInputStream.readObject 等触发类加载的过程；XStream/YAML 见 SNK-6/SNK-5）**
- 检索：`ObjectInputStream`（含 `readObject(`/`readUnshared(`）、`XMLDecoder`（`new XMLDecoder`/`readObject`）、`Kryo`（`readClassAndObject`/`readObject`）、`Hessian`/`Hessian2Input`（`readObject`）等的所有出现；同时留意自定义 `readResolve()`/`readExternal()`/`resolveClass()` 覆写。
  - 注：XStream 反序列化单独列为 **SNK-6**，YamlBeans YAML 反序列化单独列为 **SNK-5**，见下；Kafka 消息反序列化见 **SNK-7**。
- 为什么危险：反序列化数据流的解析过程会**按流中声明的类名触发类加载**（`ObjectInputStream.resolveClass` → `Class.forName` 隐式调用，等价于 SNK-1 的类加载 sink），随后按流数据实例化对象、调用其方法（gadget 链）→ 任意类加载/RCE；即使无已知 gadget，也可用于类存在性探测。
- 分级：
  - **High**：序列化数据来自不可信输入（HTTP 请求体、上传文件、外部消息队列/网络流等），且无任何过滤/白名单（无 `ObjectInputFilter`、无 `resolveClass` 白名单）。
  - **Medium**：序列化数据来自数据库、内部队列等半可信来源；或存在黑名单过滤（可被 gadget 库绕过，如常见黑名单漏项）。
  - **Info**：有完整防护 —— `ObjectInputFilter`（Java 9+ 序列化过滤器）/ `resolveClass` 白名单 / 替代安全序列化方案（JSON 等）/ 仅反序列化受信内网数据（来源明确可控）。

**SNK-4: 工作流引擎表达式与脚本执行（Activiti / Flowable / Camunda）**
- 检索：以下入口的所有出现：
  - 表达式求值：`Expression.getValue(`、`Expression.setValue(`、`ExpressionManager.createExpression(`、`ExpressionFactory.createValueExpression`、`ExpressionFactory.createMethodExpression`（UEL `#{...}`/`${...}` 在 BPMN 中求值）；
  - 脚本任务：`ScriptTaskActivityBehavior`、`ScriptingEngines`、`ScriptEngineManager`/`ScriptEngine.eval`（JSR-223，引擎求值 BPMN `<scriptTask>` 的脚本）；
  - 委派与流程部署：BPMN `delegateExpression`/`class` 属性指向的 `JavaDelegate` 实例化（触发类加载）、`RepositoryService.createDeployment(`、`addInputStream(`、`addString(`、`deploy()`（部署受控 BPMN）、`ManagementService.executeCommand(`（受控命令上下文）、`TaskService.complete(`/`RuntimeService.setVariable(`（变量进入表达式上下文求值）。
- 为什么危险：BPMN 中 `<serviceTask>` 的 `expression`/`delegateExpression`/`script` 字段会在引擎求值时执行；流程定义内容或变量若受攻击者控制，可执行任意 SpEL/UEL/Groovy/JavaScript，或经 `delegateExpression` 触发任意类加载 → RCE。
- 分级：
  - **High**：流程定义内容、脚本/表达式/委派类名来自不可信输入（用户上传 BPMN、脚本内容来自请求参数、`delegateExpression` 字符串受控），无白名单。
  - **Medium**：流程定义来自数据库/配置中心等半可信来源，或仅有脚本语言黑名单。
  - **Info**：流程定义固定常量、表达式为字面量、脚本语言白名单受限（如禁用 Groovy/JS）—— 正常流程编排，记录但不当作漏洞。

**SNK-5: YAML 反序列化（YamlBeans）**
- 检索：`YamlReader.read(`、`new YamlReader(`、`YamlConfig`、`setClassDesigner`/`setClassName` 的所有出现。
- 为什么危险：YamlBeans 解析 YAML 时，按流中声明的类名触发类加载并实例化 bean（等价 SNK-1 类加载 + SNK-3 反序列化）；若 `setClassDesigner` 返回受控类名或 YAML 内容受控，可达任意类实例化/RCE。
- 分级：
  - **High**：YAML 内容来自不可信输入（HTTP 请求体、上传文件等），且无类名白名单。
  - **Medium**：YAML 来自数据库/内部队列等半可信来源，或仅有黑名单过滤。
  - **Info**：配置了类名白名单/只解析基本类型 —— 安全对照，非漏洞。

**SNK-6: XStream 反序列化（从 SNK-3 拆出，独立规则）**
- 检索：`XStream.fromXML(`、`new XStream(` 的所有出现；同时检查安全配置对照点：`XStream.setupDefaultSecurity(`、`allowTypes(`、`allowTypesByWildcard(`、`allowTypesByRegExp(`、`denyTypes(`、`addPermission`/`denyPermission`。
- 为什么危险：XStream 反序列化 XML 时按元素/属性实例化任意类，并触发其构造/`readResolve`/反序列化回调 → RCE；XStream 1.4.7 以下默认无安全限制，1.4.18+ 引入默认安全框架但仍需显式 `allowTypes` 白名单。
- 分级：
  - **High**：XML 来自不可信输入且无 allowTypes 白名单（或 XStream < 1.4.18 未 setupDefaultSecurity）。
  - **Medium**：XML 来自半可信来源，或仅有 denyTypes 黑名单（可被 gadget 库绕过）。
  - **Info**：`setupDefaultSecurity` + `allowTypes` 精确白名单，或仅反序列化受信数据 —— 安全对照。

**SNK-7: Kafka 客户端反序列化与类加载**
- 检索：以下两类入口的所有出现：
  - 类加载型配置：值为类名、由 Kafka 客户端通过 `Class.forName` + 反射实例化的配置项 —— `key.deserializer`/`value.deserializer`/`partitioner.class`/`interceptor.classes`/`consumer.interceptor.classes`/`sasl.jaas.config`（loginModuleClass），以及 Streams 配置 `default.deserialization.exception.handler.class`/`processing.exception.handler.class`；检查这些配置值的来源（是否来自请求参数/外部配置）；
  - 消息反序列化：自定义 `Deserializer.deserialize(` 中调用 `ObjectInputStream`（等价 SNK-3），或直接以 Java 原生反序列化处理 Kafka 消息体。
- 为什么危险：Kafka 客户端多处配置项以类名为值，通过反射实例化；配置来源受控（用户可提交配置、配置中心下发受控值）→ 加载任意类 → RCE；用 Java 原生反序列化处理不可信消息等价 SNK-3 反序列化。
- 分级：
  - **High**：配置类名来自不可信输入（请求参数/配置中心受控值）无白名单，或消息经自定义反序列化器调用 `ObjectInputStream` 处理不可信数据无过滤。
  - **Medium**：配置来自半可信来源（数据库/配置中心），或消息反序列化有黑名单。
  - **Info**：配置为固定标准类名（StringDeserializer/ByteArrayDeserializer 等），消息不使用 Java 原生反序列化 —— 安全对照。

**SNK-8: Groovy 脚本执行与动态类加载**
- 检索：以下入口的所有出现：
  - 脚本执行：`GroovyShell.evaluate(`、`GroovyShell.parse(`、`groovy.lang.Script.run(`/`evaluate(`；
  - 动态类加载：`GroovyClassLoader.parseClass(`、`GroovyClassLoader.defineClass`、`new GroovyClassLoader(`；
  - 模板渲染：`GStringTemplateEngine`、`StreamingTemplateEngine`、`SimpleTemplateEngine`、`TemplateEngine.createTemplate`；
  - 方法调用与 JSR-223：`InvokerHelper.invokeMethod(`、`ScriptEngineManager` + `"groovy"` → `ScriptEngine.eval`。
  安全对照点：`SecureASTCustomizer`/`CompilerConfiguration` 白名单。
- 为什么危险：`GroovyShell.evaluate(code)` 直接执行 Groovy 源码（图灵完备语言，可调用 `Runtime.exec` 等）→ RCE；`GroovyClassLoader.parseClass` 加载受控 Groovy 源码为类（等价 SNK-1 defineClass）；模板引擎渲染受控模板内容 → SSTI → RCE。
- 分级：
  - **High**：脚本/源码/模板内容来自不可信输入，且无 SecureASTCustomizer 白名单。
  - **Medium**：来自半可信来源，或仅有黑名单（可绕过）。
  - **Info**：使用 SecureASTCustomizer 限制可调用类/方法白名单，或脚本/模板为常量 —— 安全对照。

**SNK-9: Thymeleaf 模板渲染与表达式注入（SSTI）**
- 检索：以下入口的所有出现：
  - 视图名注入：Spring MVC Controller 返回的 `String` 视图名来自用户输入（`@RequestParam`/`@PathVariable`/`@RequestBody`），且可能含 `__${...}__` 触发表达式求值（需人工检查 Controller 方法返回值来源）；
  - 模板渲染：`TemplateEngine.process(`、`SpringTemplateEngine`、`ThymeleafView`；
  - 表达式与片段：`th:text`/`th:utext`/`th:if`/`th:each`/`th:with`/`th:field`/`th:object`/`th:href` 中的 `${...}`/`*{...}` 表达式；`th:insert`/`th:replace`/`th:include` 的 `~{template :: fragment}` 片段表达式受控时加载任意模板。
- 为什么危险：模板内容或视图名受攻击者控制时，Thymeleaf 会求值其中的 `${...}`（SpEL）→ RCE；视图名注入 `__${T(java.lang.Runtime).getRuntime().exec('...')}__::..` 是 Spring + Thymeleaf 的经典 SSTI。
- 分级：
  - **High**：视图名/模板内容来自不可信输入，且无表达式转义/白名单。
  - **Medium**：模板内容半可信，或使用 `th:text`（转义）但视图名部分受控。
  - **Info**：视图名为常量、模板静态、`th:text` 转义输出 —— 安全对照。

### Source 点

**SRC-1: 文件上传（任意后缀 + 落盘）**
- 检索：`MultipartFile`、`@RequestParam("file")`、`@RequestPart`、`Part`/`getPart(`、`FileItem`/`ServletFileUpload`、`transferTo(`、`item.write(`、`part.write(`、`FileOutputStream`、`Files.copy(`、`getOriginalFilename`、`getSubmittedFileName`、`getInputStream()` 后写盘。
- 判定为高危 source 需**同时满足**：
  1. **允许任意后缀**：没有扩展名白名单校验，或只校验 ContentType、只做黑名单（jsp/jspx 黑名单可被 `.jsp.jpg`、大小写、双写、`%00`、换行绕过），或在最后落盘路径中使用了原始文件名（含 `../` 路径穿越）。
  2. **落盘到服务器**：transferTo / write / FileOutputStream / Files.copy 到磁盘（webapp 目录或可下载目录更危险；不可达目录也记为 source 但降级）。
- 分级：
  - **High**：无有效扩展名校验 + 落盘到 web 可访问目录（可写 webshell）。
  - **Medium**：无校验但落盘到不可达目录，或有黑名单校验（可绕过）。
  - **Info**：有扩展名白名单 + 落盘路径受控（安全对照，不报告为漏洞）。

**SRC-2: getResourceAsStream**
- 检索：`getResourceAsStream(` 的所有出现（`Class.getResourceAsStream`、`ClassLoader.getResourceAsStream`、`Thread.currentThread().getContextClassLoader().getResourceAsStream`）。
- 为什么危险：资源路径若受攻击者控制，可加载攻击者已写入 classpath / webapp 目录的资源（如用户上传的 class、配置文件、模板），或做资源路径穿越读取文件；常与反序列化/模板注入结合。
- 分级：
  - **High/Medium**：资源名来自外部输入。
  - **Info**：常量资源路径。

**SRC-3: URL 对象读取（SSRF 入口）**
- 检索：`new URL(`、`url.openStream(`、`openConnection()`、`getInputStream()`、`URLConnection`、`HttpURLConnection`、`HttpClient`/`RestTemplate`/`okhttp` 等（后者辅助确认是否已换用安全组件）。
- 判定为 source 的条件：创建 `URL` 对象的字符串可能来自外部输入，且调用了 `openStream()` 或 `openConnection().getInputStream()` 读取内容，**且没有** `instanceof HttpURLConnection` 强制转换 + 协议（http/https）与主机白名单校验。
- 分级：
  - **High**：URL 来自不可信输入 + 直接 openStream/getInputStream 读取，无协议/主机限制（可探测内网、访问云元数据 169.254.169.254、file:// 读文件）。
  - **Medium**：仅强转了 HttpURLConnection 但无主机白名单（仍可 SSRF 内网），或来源半可信。
  - **Info**：HttpURLConnection 强转 + 协议白名单 + 主机白名单齐全（安全对照）。

**SRC-4: RandomAccessFile / ZipFile 缓存不关闭（文件描述符泄漏）**
- 检索：`RandomAccessFile` 与 `ZipFile`（含继承它的 `JarFile`）的所有出现，覆盖全部构造形式：`new RandomAccessFile(`、`new ZipFile(`（`String`/`File`/`File+mode`/`File+Charset` 等重载）、`new JarFile(`。重点检查：
  1. 对象是否被**缓存/长生命周期持有**：存入字段、静态集合（`Map`/`List`/`Set`/缓存表）、实例变量、或在循环/请求处理中累积而不释放；
  2. 是否有**关闭路径**：`finally` 中 `close()`、try-with-resources、或所有权明确转移到会负责关闭的代码。
- 为什么危险：每个 `RandomAccessFile` / `ZipFile` 实例都在进程内占用一个文件描述符（fd），操作系统对进程 fd 数量有上限（ulimit）。若对象被缓存且从不关闭，fd 被持续占用不释放：
  - 长期运行后 fd 耗尽 → 后续所有文件打开/网络连接/新连接创建失败 → **服务 DoS**；
  - 攻击者若可控制被缓存对象的文件路径或触发频率，可**加速 fd 耗尽**（反复传入新路径让缓存无限增长）；
  - 被缓存的文件句柄还会阻止文件被删除/重命名（Windows 上尤其明显），并可能持有敏感文件内容于内存。
- 分级：
  - **High**：创建路径或触发时机受外部输入控制（请求参数、上传文件名等，攻击者可批量制造新实例）+ 缓存不关闭 → fd 耗尽可被主动利用。
  - **Medium**：路径固定/半可信来源，但对象缓存不关闭（缓慢泄漏，长期运行后仍会耗尽 fd）。
  - **Info**：try-with-resources / finally 正确关闭，或对象生命周期明确（安全对照）。

## 严重级别速查

| 级别 | 含义 |
|------|------|
| High | 不可信外部输入直达 sink/source，无有效校验 |
| Medium | 半可信来源，或校验存在但可绕过/不完整 |
| Info | 常量、固定值、已有完整白名单 —— 仍列入报告（备注"安全对照/非漏洞"），便于使用者核对 |

报告里**必须同时包含高危项与 Info 对照项**：这能让使用者一眼看出哪些常量用法、白名单写法是"安全写法"，避免误报堆积。

## 污点分析框架

### 数据流模型

```
[不可信输入入口] --传播--> [中间节点(字段/参数/返回值/集合/字符串变换)] --传播--> [终点: 13类规则命中点]
                        └-------- 净化点(白名单/强类型/参数化) --------┘
```

### 污点源（路径起点，不可信输入入口）

凡是可能被攻击者影响的数据来源，包括但不限于：
- **Web 层（最高优先级）**：`@RequestParam`、`@PathVariable`、`@RequestBody`、`@RequestHeader`、`HttpServletRequest` 的 `getParameter`/`getHeader`/`getInputStream`/`getParts`、`MultipartFile`（文件名与内容）、`Cookie`、`Principal` 相关外部身份数据
- **半可信来源**：`System.getenv`/`System.getProperty`（用户可控配置）、外部配置文件、数据库/消息队列读出的数据、线程局部量

### 传播保持规则（污点经过以下操作仍视为"污点保持"）

- 字段赋值与读取（`this.path = path` 后 `this.path` 仍是污点）
- 方法参数传递（`a.foo(x)`、构造器传参）
- 返回值传递（`String s = helper.get();`）
- 集合存取（`List`/`Map`/`Set` 的 put/get 同源）
- 简单字符串变换：拼接（`"dir/" + name`）、`substring`/`concat`/`trim`/`toLowerCase`/`toUpperCase`/`replace`（简单字符替换）、格式化（`String.format` 含污点实参）、`String.valueOf`

### 净化点规则（污点在此被"切断/降级"）

- **完整净化**（视为净化点，结果标"已净化 Info"）：白名单校验通过（扩展名/类名/主机名 allowlist 精确匹配）、强类型转换（枚举映射、`Integer.parseInt` 等且结果确为受控枚举）、参数化构造（如 `PreparedStatement` 语义等价物）
- **弱净化**（不算净化，仍按原级别报告并注明"可绕过"）：黑名单过滤、去特殊字符、`startsWith` 前缀检查、ContentType 检查、`endsWith` 单个后缀检查
- 净化点之后的路径段记为"净化后"，终点分级降为 Info；多条路径中只要有**一条**未净化路径到达终点，该终点按最高级别（High/Medium）报告，净化路径单独列出

### 置信度分级（每条路径必标其一）

| 置信度 | 含义 |
|--------|------|
| 确证路径 | 调用链连续完整、入口明确（Web 层注解/Request 或已确认的可控源）、无净化或弱净化，无未验证假设 |
| 可疑路径 | 链中存在未验证假设：依赖注释声明（如 javadoc 说"由前端传入"但未见调用方）、接口多实现（未确认实际装配）、半可信来源 |
| 待确认 | 回溯穷尽仍无可信入口（疑似死代码/定时器/内部触发）、超出深度上限、动态分发无法静态解析 |

### 调用图回溯规则

- **反向回溯优先**：从每个终点出发，问"谁调用了这个方法？参数从哪来？"，逐跳回溯到不可信输入或穷尽。终点数量远少于入口数量，反向追踪成本更低且不遗漏。
- **接口多实现**：终点在接口实现类中时，追踪**所有**实现类，每实现一条路径，标"可疑路径（多实现）"；若存在 Spring 装配信息（`@Service`/`@Bean`/XML），据此缩小范围并可升级为确证。
- **动态分发**：`Method.invoke`、lambda、方法引用等无法静态解析的跳转，标记"动态分发: 文件:行号，超出静态分析"并降为待确认，不阻断路径呈现。
- **环路/递归**：同一方法在一条路径中只出现一次（访问去重）；深度上限 **10 层**，超限标记"超出深度（>10跳），待确认"不再展开。
- **死胡同**：回溯穷尽仍未找到不可信输入的终点，**照常列出**，标注"无可信入口（疑似死代码/内部触发），待确认"——不静默丢弃。
- **传播经过范围外代码**：链路中间节点即使涉及范围外操作（如 JNDI），只写"传递经过 文件:行号，不评价"。

## 审计流程（三阶段）

### 阶段一：终点定位
1. **确定目标**：用户给的目录或文件；没有则用当前目录。列出所有 `.java` 文件（用 glob 搜 `**/*.java`）。
2. **检索命中**：对上述 13 条规则用 grep（带行号）在全部 Java 文件中定位候选终点。grep 模式示例：
   - SNK-1: `Class\.forName|loadClass\(|URLClassLoader|defineClass`
   - SNK-2: `DriverManager\.(getConnection|connect)`
   - SNK-3: `ObjectInputStream|readObject\(|XMLDecoder|Kryo|Hessian`（XStream 见 SNK-6）
   - SNK-4: `Expression\.getValue|Expression\.setValue|ExpressionManager|ScriptTaskActivityBehavior|ScriptingEngines|ScriptEngineManager|delegateExpression|createDeployment|JavaDelegate|ExpressionFactory|executeCommand`
   - SNK-5: `YamlReader|YamlConfig`
   - SNK-6: `XStream|fromXML`
   - SNK-7: `Deserializer|partitioner\.class|interceptor\.classes|sasl\.jaas\.config|exception\.handler\.class|key\.deserializer|value\.deserializer`
   - SNK-8: `GroovyShell|GroovyClassLoader|GStringTemplateEngine|StreamingTemplateEngine|SimpleTemplateEngine|createTemplate|InvokerHelper|ScriptEngine`
   - SNK-9: `org\.thymeleaf|ThymeleafView|SpringTemplateEngine|TemplateEngine`（视图名注入需人工检查 Controller 返回 String 视图名是否来自用户输入；命中 org.thymeleaf/TemplateEngine 等令牌后，需在项目内排查 Controller 返回值是否来自用户输入）
   - SRC-1: `MultipartFile|transferTo|getPart\(|FileItem|getOriginalFilename|Files\.copy|FileOutputStream`
   - SRC-2: `getResourceAsStream`
   - SRC-3: `new URL\(|openStream\(|openConnection\(|HttpURLConnection`
   - SRC-4: `RandomAccessFile|ZipFile|JarFile`
   把所有命中点登记为"终点候选"（文件:行号 + 所属方法 + 所属类）。

### 阶段二：污点回溯
3. **反向回溯**：对每个终点候选，用 grep 找"谁调用了这个方法"（方法名/构造器在整个项目中的调用点），用 read 检查：
   - 调用方的实参从哪来（HTTP 注解？另一个方法参数？字段？常量？另一个方法返回值？）；
   - 若实参是字段：找字段赋值点（构造器、setter、其它方法），继续回溯；
   - 若实参是方法返回值：找该方法定义，进入其内部回溯参数来源；
   - 途经的校验点：判断是完整净化还是弱净化；
   - 遇到接口：查全部实现类；遇到动态分发：标注降级。
   逐跳推进，直到：找到不可信输入入口（路径完成）或穷尽（死胡同/超深度/动态分发）。
   - **只分析命中点与上述 13 类规则相关的上下文**。阅读过程中看到其它可疑代码（JNDI、硬编码凭据等）时不要展开、不要记入报告（路径中间经过时仅作传递节点）。
4. **正向核对（覆盖矩阵）**：列出全部 Web 入口（Controller/过滤器/Servlet 的 HTTP 处理方法），逐一确认哪些入口已关联到终点、哪些入口没有任何可达终点——防止反向回溯遗漏入口。

### 阶段三：分级与报告
5. **分级**：每条路径按——终点规则级别（High/Medium/Info）+ 置信度（确证/可疑/待确认）+ 净化状态（未净化/弱校验可绕过/已净化Info），写出"为什么危险 + 威胁场景"。
6. **产出报告**：按下方模板生成 Markdown 报告，保存为 `<目标目录>/source-sink-report.md`（用户指定其他路径则从命），并在回复中给出报告路径与统计摘要。报告只包含 13 类规则的命中项与"安全对照"项。

## 报告模板

ALWAYS 使用以下结构：

```markdown
# Source-Sink 审计报告（含污点分析）
报告目标: <目录/文件>
扫描文件数: <n> Java 文件 · 扫描时间: <时间>

## 污点分析覆盖矩阵
| 入口（不可信输入） | 可达终点 | 路径数 | 状态 |
|--------------------|----------|--------|------|
| @GetMapping("/reflect/load") className (Foo.java:12) | SNK-1 Class.forName | 1 | 确证 |
| （统计）入口总数 x · 终点总数 y · 确证路径 p · 可疑路径 q · 待确认 r |

## 概览
| 类别 | High | Medium | Info |
|------|------|--------|------|
| Sink: 类加载(SNK-1) | x | x | x |
| Sink: JDBC 连接(SNK-2) | x | x | x |
| Sink: 反序列化-原生(SNK-3) | x | x | x |
| Sink: 工作流表达式/脚本(SNK-4) | x | x | x |
| Sink: YAML反序列化-YamlBeans(SNK-5) | x | x | x |
| Sink: XStream反序列化(SNK-6) | x | x | x |
| Sink: Kafka反序列化/类加载(SNK-7) | x | x | x |
| Sink: Groovy脚本执行(SNK-8) | x | x | x |
| Sink: Thymeleaf SSTI(SNK-9) | x | x | x |
| Source: 文件上传 | x | x | x |
| Source: getResourceAsStream | x | x | x |
| Source: URL 读取(SSRF) | x | x | x |
| Source: RandomAccessFile/ZipFile(fd) | x | x | x |

## 高危发现（High）
### 1. [Sink/SNK-1] Class.forName — src/main/java/com/example/Foo.java:42
- **严重级别**: High
- **置信度**: 确证路径
- **净化状态**: 未净化
- **污点路径链**:
  `FooController.java:12 (@RequestParam String className)` → `FooController.java:14 (fooService.process(className) 参数传递)` → `FooService.java:20 (fooDao.findByName(name) 参数传递)` → `FooDao.java:42 (Class.forName(className))` [终点]
- **代码片段**（终点）:
  ```java
  String className = request.getParameter("className");
  Class<?> clazz = Class.forName(className);
  ```
- **威胁场景**: 攻击者可控类名 → 加载任意类/恶意驱动，配合反序列化 gadget 可达 RCE
- **修复建议**: 类名白名单校验；避免使用反射加载用户输入；用枚举/映射替代

## 中危发现（Medium）
...

## 待确认路径（置信度=待确认 或 死胡同/超深度）
### N. [Sink/SNK-2] DriverManager.getConnection — .../DbDao.java:8
- **严重级别**: Medium（若入口确认则升 High）
- **置信度**: 待确认 —— 未见调用方，疑似死代码或由反射触发；行号 :8
- **说明**: 回溯穷尽未找到调用点；建议在完整代码库中确认是否存在动态调用

## 对照项（Info / 安全写法 / 已净化）
### N. [Sink/SNK-1] Class.forName — .../DriverLoader.java:10
- **严重级别**: Info —— 常量类名 `com.mysql.cj.jdbc.Driver`，正常驱动加载，非漏洞
```

## 注意事项

- 每条报告项必须有**文件路径 + 行号**，行号用 grep 结果为准，不要凭记忆。
- **污点路径链的每一跳都必须带 "文件:行号"**，并注明该跳的传递方式（参数/字段/返回值/净化点/动态分发）。
- 区分"漏洞"与"可能被误用的安全写法"：报告的目的是让使用者快速决策，因此 Info 对照项和已净化路径同样重要。
- **同一终点存在多条路径时全部列出**（如经接口多实现、经不同入口），不要只挑一条"最像的"。
- 不确定来源时标注"来源待确认"并说明依据，不要硬套 High。
- 代码库较大时按规则分组批量处理，先 grep 摸清全景再逐个回溯，避免在单个文件上花费过多轮次。
- 允许为可复现性写一次性分析脚本（如生成"谁调用谁"的调用关系表），但报告只呈现结论与证据链。
- 目标是 Java 代码；若目录里没有 `.java` 文件，先向用户说明并询问范围。
- **牢记范围边界**：报告只回答"这 13 类规则的 sink/source 点在哪里、是否有污点路径到达、什么级别"，其它安全问题不是本技能的任务。对于 SNK-4/8/9，只有经由本技能列出的具体组件入口（工作流引擎/Groovy/Thymeleaf）的表达式/脚本/模板注入才报告；不经这些组件入口的裸 SpEL/EL/模板注入不在范围内。
