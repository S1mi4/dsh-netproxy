---
name: java-source-sink-audit
description: 审计 Java 代码库，**仅**检索本技能明确定义的 sink 点（SNK-1 Class.forName 反射加载、SNK-2 JDBC 连接 DriverManager.getConnection/connect）与 source 点（SRC-1 任意后缀文件上传落盘、SRC-2 getResourceAsStream 使用、SRC-3 URL 对象未强制转换 HttpURLConnection 却调用 openStream/getInputStream 的 SSRF 入口、SRC-4 RandomAccessFile/ZipFile/JarFile 缓存不关闭导致的文件描述符泄漏），输出"文件路径+行号+类型+危险级别"的结构化报告。**范围外的一切漏洞类型（如 JNDI 注入、SQL 注入、命令注入、XSS、CSRF、硬编码凭据、弱加密等）一律不检索、不报告，即使代码中存在。** 凡用户要求查找/检索/审计代码中的 sink 点、source 点、漏洞触发点、污染源、Class.forName、JDBC 连接串、任意文件上传、getResourceAsStream、URL/SSRF 相关危险调用、RandomAccessFile、ZipFile、JarFile、fd/文件描述符泄漏，或要求给出带文件位置与危险分级的漏洞清单时，都必须使用本技能，即使他们没有明确说出"sink/source"这类术语。
---

# Java Source-Sink 审计

## 这个技能做什么

对一个 Java 代码库做**漏洞 sink 点 + source 点检索**，产出结构化审计报告。它只做"定位 + 基础上下文判断"，不做跨方法的完整污点追踪：判断某参数是否可能来自外部输入时，检查该方法/类的上下文（HTTP 参数、Request 对象、上传文件、URL 字符串来源、有无校验）即可，不需要构建全量调用图。

**本技能只做一件事：按下方"检查规则"逐条检索并报告，不做任何范围外审计。**

## 范围边界（重要，必须遵守）

- 本技能覆盖**且仅覆盖**以下 6 类规则：SNK-1、SNK-2、SRC-1、SRC-2、SRC-3、SRC-4。
- **禁止**检索、报告或"顺带提示"任何范围外的问题，即使代码中明显存在，包括但不限于：
  - JNDI 注入（`InitialContext.lookup` 等）、表达式注入、模板注入
  - SQL 注入、命令注入、文件包含/读取（非上述规则路径）
  - XSS、CSRF、SSRF 变体外的其它请求伪造、反序列化漏洞
  - 硬编码凭据、弱加密、`useSSL=false` 等配置卫生问题
  - 资源未关闭（除 SRC-4 列出的 RandomAccessFile/ZipFile/JarFile 缓存场景之外的一般性问题）
- 报告**不得**出现"附加发现""其他问题""顺带提示"等章节；发现范围外问题时，要么忽略，要么仅在不影响报告聚焦的前提下标注"不在本技能范围"（不超过一行，不展开）。
- 如果用户明确要求扩展范围（如"顺便看看 JNDI"），才可追加，并在报告开头注明"本次为范围扩展审计"。

## 检查规则

### Sink 点

**SNK-1: Class.forName（反射加载）**
- 检索：`Class.forName(` 的所有出现（含 `Class.forName(name, initialize, loader)` 三参变体）。
- 为什么危险：加载的类名若受攻击者控制，可以加载任意类（如攻击者已写入磁盘的 class 文件、恶意 JDBC 驱动、配合反序列化 gadget 的类），触发静态初始化代码 → 潜在 RCE。
- 分级：
  - **High**：类名来自不可信输入（HTTP 参数、请求体、上传文件名、用户可控配置且无白名单）。
  - **Medium**：类名来自数据库/配置文件等半可信来源，或虽有校验但可绕过（黑名单、大小写、前后缀拼接）。
  - **Info**：常量类名，如 `Class.forName("com.mysql.cj.jdbc.Driver")` —— 正常驱动加载，记录但不当作漏洞。

**SNK-2: JDBC 连接（DriverManager.getConnection / connect）**
- 检索：`DriverManager.getConnection(`、`DriverManager.connect(`、`java.sql.DriverManager` 的所有使用。
- 为什么危险：JDBC URL 若受攻击者控制，可连接攻击者指定的数据库（MySQL/PostgreSQL 假服务器）或内网地址，配合 URL 中的 `autoDeserialize=true`、H2/HSQLDB 内存库等触发服务端反序列化/任意类加载 → RCE；也是 SSRF 的一类。
- 分级：
  - **High**：JDBC URL 来自不可信输入。
  - **Medium**：URL 拼接自半可信来源（如用户输入拼前缀），或仅校验了前缀（`startsWith("jdbc:mysql")`）可绕过。
  - **Info**：URL 为固定常量/来自可信配置。

### Source 点

**SRC-1: 文件上传（任意后缀 + 落盘）**
- 检索：`MultipartFile`、`@RequestParam("file")`、`@RequestPart`、`Part`/`getPart(`、`FileItem`/`ServletFileUpload`、`transferTo(`、`item.write(`、`part.write(`、`FileOutputStream`、`Files.copy(`、`getOriginalFilename`、`getSubmittedFileName`、`getInputStream()` 后写盘。
- 判定为高危 source 需**同时满足**：
  1. **允许任意后缀**：没有扩展名白名单校验，或只校验 ContentType、只做黑名单（jsp/jspx 黑名单可被 `.jsp.jpg`、大小写、双写、`%00`、换行绕过），或在最后落盘路径中使用了原始文件名（含 `../` 路径穿越）。
  2. **落盘到服务器**：transferTo / write / FileOutputStream / Files.copy 到磁盘（webapp 目录或可下载目录更危险；不可达目录也记为 source 但降级）。
- 分级：
  - **High**：无有效扩展名校验 + 落盘到 web 可访问目录（可写 webshell）。
  - **Medium**：无校验但落盘到不可达目录，或有黑名单校验（可绕过）。
  - **Info**：有扩展名白名单 + 落盘路径受控（安全对照，不报告为漏洞）。

**SRC-2: getResourceAsStream**
- 检索：`getResourceAsStream(` 的所有出现（`Class.getResourceAsStream`、`ClassLoader.getResourceAsStream`、`Thread.currentThread().getContextClassLoader().getResourceAsStream`）。
- 为什么危险：资源路径若受攻击者控制，可加载攻击者已写入 classpath / webapp 目录的资源（如用户上传的 class、配置文件、模板），或做资源路径穿越读取文件；常与反序列化/模板注入结合。
- 分级：
  - **High/Medium**：资源名来自外部输入。
  - **Info**：常量资源路径。

**SRC-3: URL 对象读取（SSRF 入口）**
- 检索：`new URL(`、`url.openStream(`、`openConnection()`、`getInputStream()`、`URLConnection`、`HttpURLConnection`、`HttpClient`/`RestTemplate`/`okhttp` 等（后者辅助确认是否已换用安全组件）。
- 判定为 source 的条件：创建 `URL` 对象的字符串可能来自外部输入，且调用了 `openStream()` 或 `openConnection().getInputStream()` 读取内容，**且没有** `instanceof HttpURLConnection` 强制转换 + 协议（http/https）与主机白名单校验。
- 分级：
  - **High**：URL 来自不可信输入 + 直接 openStream/getInputStream 读取，无协议/主机限制（可探测内网、访问云元数据 169.254.169.254、file:// 读文件）。
  - **Medium**：仅强转了 HttpURLConnection 但无主机白名单（仍可 SSRF 内网），或来源半可信。
  - **Info**：HttpURLConnection 强转 + 协议白名单 + 主机白名单齐全（安全对照）。

**SRC-4: RandomAccessFile / ZipFile 缓存不关闭（文件描述符泄漏）**
- 检索：`RandomAccessFile` 与 `ZipFile`（含继承它的 `JarFile`）的所有出现，覆盖全部构造形式：`new RandomAccessFile(`、`new ZipFile(`（`String`/`File`/`File+mode`/`File+Charset` 等重载）、`new JarFile(`。重点检查：
  1. 对象是否被**缓存/长生命周期持有**：存入字段、静态集合（`Map`/`List`/`Set`/缓存表）、实例变量、或在循环/请求处理中累积而不释放；
  2. 是否有**关闭路径**：`finally` 中 `close()`、try-with-resources、或所有权明确转移到会负责关闭的代码。
- 为什么危险：每个 `RandomAccessFile` / `ZipFile` 实例都在进程内占用一个文件描述符（fd），操作系统对进程 fd 数量有上限（ulimit）。若对象被缓存且从不关闭，fd 被持续占用不释放：
  - 长期运行后 fd 耗尽 → 后续所有文件打开/网络连接/新连接创建失败 → **服务 DoS**；
  - 攻击者若可控制被缓存对象的文件路径或触发频率，可**加速 fd 耗尽**（反复传入新路径让缓存无限增长）；
  - 被缓存的文件句柄还会阻止文件被删除/重命名（Windows 上尤其明显），并可能持有敏感文件内容于内存。
- 分级：
  - **High**：创建路径或触发时机受外部输入控制（请求参数、上传文件名等，攻击者可批量制造新实例）+ 缓存不关闭 → fd 耗尽可被主动利用。
  - **Medium**：路径固定/半可信来源，但对象缓存不关闭（缓慢泄漏，长期运行后仍会耗尽 fd）。
  - **Info**：try-with-resources / finally 正确关闭，或对象生命周期明确（安全对照）。

## 严重级别速查

| 级别 | 含义 |
|------|------|
| High | 不可信外部输入直达 sink/source，无有效校验 |
| Medium | 半可信来源，或校验存在但可绕过/不完整 |
| Info | 常量、固定值、已有完整白名单 —— 仍列入报告（备注"安全对照/非漏洞"），便于使用者核对 |

报告里**必须同时包含高危项与 Info 对照项**：这能让使用者一眼看出哪些常量用法、白名单写法是"安全写法"，避免误报堆积。

## 审计流程

1. **确定目标**：用户给的目录或文件；没有则用当前目录。列出所有 `.java` 文件（用 glob 搜 `**/*.java`）。
2. **检索命中**：对上述每条规则用 grep（带行号）在全部 Java 文件中定位候选点。grep 模式示例：
   - SNK-1: `Class\.forName`
   - SNK-2: `DriverManager\.(getConnection|connect)`
   - SRC-1: `MultipartFile|transferTo|getPart\(|FileItem|getOriginalFilename|Files\.copy|FileOutputStream`
   - SRC-2: `getResourceAsStream`
   - SRC-3: `new URL\(|openStream\(|openConnection\(|HttpURLConnection`
   - SRC-4: `RandomAccessFile|ZipFile|JarFile`
3. **读上下文**：对每个命中点用 read 读取该文件前后 20~40 行，确认：
   - 该参数/URL/文件名来自哪里（方法参数？HTTP 注解？Request 方法？常量？配置文件？）；
   - 有无校验（白名单/黑名单/协议检查）及其位置；
   - 落盘目标路径、是否 web 可访问。
   - **只分析命中点与上述 6 类规则相关的上下文**。阅读过程中看到其它可疑代码（JNDI、硬编码凭据等）时不要展开、不要记入报告。
4. **分级**：按上表给出 High / Medium / Info，并为每条写出"为什么危险 + 威胁场景"。
5. **产出报告**：按下方模板生成 Markdown 报告，保存为 `<目标目录>/source-sink-report.md`（用户指定其他路径则从命），并在回复中给出报告路径与统计摘要。报告只包含 6 类规则的命中项与"安全对照"项。

## 报告模板

ALWAYS 使用以下结构：

```markdown
# Source-Sink 审计报告
报告目标: <目录/文件>
扫描文件数: <n> Java 文件 · 扫描时间: <时间>

## 概览
| 类别 | High | Medium | Info |
|------|------|--------|------|
| Sink: Class.forName | x | x | x |
| Sink: JDBC 连接 | x | x | x |
| Source: 文件上传 | x | x | x |
| Source: getResourceAsStream | x | x | x |
| Source: URL 读取(SSRF) | x | x | x |
| Source: RandomAccessFile/ZipFile(fd) | x | x | x |

## 高危发现（High）
### 1. [Sink/SNK-1] Class.forName — src/main/java/com/example/Foo.java:42
- **类型**: Sink（Class.forName 反射加载）
- **严重级别**: High
- **代码片段**:
  ```java
  String className = request.getParameter("className");
  Class<?> clazz = Class.forName(className);
  ```
- **数据来源**: className 直接来自 HTTP 参数，无任何校验
- **威胁场景**: 攻击者可控类名 → 加载任意类/恶意驱动，配合反序列化 gadget 可达 RCE
- **修复建议**: 类名白名单校验；避免使用反射加载用户输入；用枚举/映射替代

## 中危发现（Medium）
...

## 对照项（Info / 安全写法）
### N. [Sink/SNK-1] Class.forName — .../DriverLoader.java:10
- **严重级别**: Info —— 常量类名 `com.mysql.cj.jdbc.Driver`，正常驱动加载，非漏洞
```

## 注意事项

- 每条报告项必须有**文件路径 + 行号**，行号用 grep 结果为准，不要凭记忆。
- 区分"漏洞"与"可能被误用的安全写法"：报告的目的是让使用者快速决策，因此 Info 对照项同样重要。
- 不确定来源时标注"来源待确认"并说明依据，不要硬套 High。
- 代码库较大时按规则分组批量处理，先 grep 摸清全景再逐个 read 确认，避免在单个文件上花费过多轮次。
- 目标是 Java 代码；若目录里没有 `.java` 文件，先向用户说明并询问范围。
- **牢记范围边界**：报告只回答"这 6 类规则的 sink/source 点在哪里、什么级别"，其它安全问题不是本技能的任务。