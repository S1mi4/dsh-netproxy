package com.demo.web;

import com.demo.svc.YamlParseService;
import com.demo.svc.YamlSafeService;
import org.springframework.web.bind.annotation.*;

/**
 * YAML 解析入口（YamlBeans）。
 */
@RestController
public class YamlController {

    private final YamlParseService yamlParseService;
    private final YamlSafeService yamlSafeService;

    public YamlController(YamlParseService yamlParseService, YamlSafeService yamlSafeService) {
        this.yamlParseService = yamlParseService;
        this.yamlSafeService = yamlSafeService;
    }

    /** 解析用户提交的 YAML 配置（高危：无类名白名单）。 */
    @PostMapping("/yaml/parse")
    public String parse(@RequestBody String yaml) throws Exception {
        return yamlParseService.parse(yaml);
    }

    /** 安全对照：用白名单配置解析。 */
    @GetMapping("/yaml/safe")
    public String parseSafe() throws Exception {
        return yamlSafeService.parseWithWhitelist();
    }
}
