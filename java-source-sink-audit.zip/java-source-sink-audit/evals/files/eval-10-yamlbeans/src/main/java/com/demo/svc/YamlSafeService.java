package com.demo.svc;

import com.esotericsoftware.yamlbeans.YamlConfig;
import com.esotericsoftware.yamlbeans.YamlReader;
import java.io.StringReader;

/**
 * 安全对照：YamlConfig 设置类名白名单，只允许受控类。
 */
public class YamlSafeService {

    public String parseWithWhitelist() throws Exception {
        YamlConfig config = new YamlConfig();              // SNK-5 Info
        config.setClassDesigner(name -> {                  // 类名白名单
            if ("com.demo.dto.Config".equals(name)) return Config.class;
            throw new IllegalArgumentException("不允许的类: " + name);
        });
        YamlReader reader = new YamlReader(new StringReader("name: demo"), config);
        Object obj = reader.read();
        return String.valueOf(obj);
    }

    static class Config {
        String name;
    }
}
