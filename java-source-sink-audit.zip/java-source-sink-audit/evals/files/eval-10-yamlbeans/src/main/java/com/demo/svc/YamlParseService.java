package com.demo.svc;

import com.demo.engine.YamlEngine;
import java.io.StringReader;

/**
 * YAML 业务层：把请求体传递到引擎层。
 */
public class YamlParseService {

    private final YamlEngine yamlEngine;

    public YamlParseService(YamlEngine yamlEngine) {
        this.yamlEngine = yamlEngine;
    }

    public String parse(String yaml) throws Exception {
        return yamlEngine.read(new StringReader(yaml));   // 参数传递
    }
}
