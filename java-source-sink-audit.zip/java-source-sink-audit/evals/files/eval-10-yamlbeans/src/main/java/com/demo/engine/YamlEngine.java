package com.demo.engine;

import com.esotericsoftware.yamlbeans.YamlReader;
import java.io.Reader;

/**
 * YamlBeans 引擎层。
 */
public class YamlEngine {

    /** 高危：无类名白名单，YAML 中的 !!类名 可触发任意类实例化 → RCE。 */
    public String read(Reader reader) throws Exception {
        YamlReader yamlReader = new YamlReader(reader);   // SNK-5 sink
        Object obj = yamlReader.read();                    // SNK-5 sink
        return String.valueOf(obj);
    }
}
