package com.demo.web;

import com.demo.svc.KafkaConfigService;
import com.demo.svc.KafkaMsgService;
import com.demo.svc.KafkaSafeService;
import org.springframework.web.bind.annotation.*;

/**
 * Kafka 客户端配置与消息处理入口。
 */
@RestController
public class KafkaController {

    private final KafkaConfigService kafkaConfigService;
    private final KafkaMsgService kafkaMsgService;
    private final KafkaSafeService kafkaSafeService;

    public KafkaController(KafkaConfigService kafkaConfigService,
                           KafkaMsgService kafkaMsgService,
                           KafkaSafeService kafkaSafeService) {
        this.kafkaConfigService = kafkaConfigService;
        this.kafkaMsgService = kafkaMsgService;
        this.kafkaSafeService = kafkaSafeService;
    }

    /** 用用户提供的反序列化器类名配置消费者。 */
    @GetMapping("/kafka/config")
    public String config(@RequestParam("deserializer") String deserializer) {
        return kafkaConfigService.configure(deserializer);
    }

    /** 消费消息（消息体来自请求，自定义反序列化器调用 ObjectInputStream）。 */
    @PostMapping("/kafka/consume")
    public String consume(@RequestBody byte[] message) throws Exception {
        return kafkaMsgService.consume(message);
    }

    /** 安全对照：固定标准反序列化器配置。 */
    @GetMapping("/kafka/safe")
    public String safeConfig() {
        return kafkaSafeService.configureFixed();
    }
}
