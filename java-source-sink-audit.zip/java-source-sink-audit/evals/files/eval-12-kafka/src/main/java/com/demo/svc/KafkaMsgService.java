package com.demo.svc;

import org.apache.kafka.common.serialization.Deserializer;
import java.io.*;

/**
 * Kafka 消息处理层：自定义反序列化器调用 ObjectInputStream。
 */
public class KafkaMsgService {

    /** 高危：消息体来自请求，用 ObjectInputStream 反序列化 → 等价 SNK-3。 */
    public String consume(byte[] message) throws Exception {
        ObjectDeserializer deserializer = new ObjectDeserializer();
        Object obj = deserializer.deserialize("topic", message);
        return String.valueOf(obj);
    }

    /** 自定义反序列化器：无 ObjectInputFilter 白名单。 */
    static class ObjectDeserializer implements Deserializer<Object> {
        @Override
        public Object deserialize(String topic, byte[] data) {
            try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data))) {
                return in.readObject();   // SNK-7 / SNK-3 sink
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
