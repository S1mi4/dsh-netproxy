package com.demo.legacy;

import javax.naming.InitialContext;

/**
 * 范围外代码：JNDI 注入不在本技能范围（SNK-7 仅覆盖 Kafka 客户端反序列化/类加载）。
 * 审计时若遇到此类代码，应忽略，不得列为发现。
 */
public class LegacyJndiBean {

    public Object lookup(String name) throws Exception {
        return new InitialContext().lookup(name);   // 范围外：JNDI 注入，不报告
    }
}
