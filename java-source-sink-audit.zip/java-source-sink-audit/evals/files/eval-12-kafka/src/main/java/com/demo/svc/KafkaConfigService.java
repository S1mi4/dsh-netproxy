package com.demo.svc;

import java.util.Properties;

/**
 * Kafka 配置层：用户输入的类名被设为 value.deserializer，由 Kafka 客户端反射加载。
 */
public class KafkaConfigService {

    /** 高危：value.deserializer 值来自请求参数 → Kafka 客户端 Class.forName 反射加载任意类。 */
    public String configure(String deserializer) {
        Properties props = new Properties();
        props.put("value.deserializer", deserializer);   // SNK-7 sink（类加载型配置）
        return "configured: " + deserializer;
    }
}
