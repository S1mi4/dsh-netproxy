package com.demo.svc;

import java.util.Properties;

/**
 * 安全对照：固定标准反序列化器配置，消息不使用 Java 原生反序列化。
 */
public class KafkaSafeService {

    /** Info：value.deserializer 固定为标准 ByteArrayDeserializer（常量类名）。 */
    public String configureFixed() {
        Properties props = new Properties();
        props.put("value.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer");  // SNK-7 Info
        return "fixed config";
    }
}
