package com.demo.svc;

import groovy.lang.GroovyShell;
import org.codehaus.groovy.control.CompilerConfiguration;
import org.codehaus.groovy.control.customizers.SecureASTCustomizer;

/**
 * 安全对照：SecureASTCustomizer 白名单限制可调用类 / 方法。
 */
public class GroovySafeService {

    public String evaluateWithWhitelist() throws Exception {
        SecureASTCustomizer customizer = new SecureASTCustomizer();   // SNK-8 Info
        customizer.setIndirectImportCheckEnabled(true);
        // 限制可调用的接收器白名单（仅允许基本类型运算）
        CompilerConfiguration config = new CompilerConfiguration();
        config.addCompilationCustomizers(customizer);
        GroovyShell shell = new GroovyShell(config);
        Object result = shell.evaluate("1 + 1");   // 常量脚本
        return String.valueOf(result);
    }
}
