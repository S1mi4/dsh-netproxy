package com.demo.web;

import com.demo.svc.GroovyEvalService;
import com.demo.svc.GroovyTemplateService;
import com.demo.svc.GroovySafeService;
import org.springframework.web.bind.annotation.*;

/**
 * Groovy 脚本 / 模板执行入口。
 */
@RestController
public class GroovyController {

    private final GroovyEvalService groovyEvalService;
    private final GroovyTemplateService groovyTemplateService;
    private final GroovySafeService groovySafeService;

    public GroovyController(GroovyEvalService groovyEvalService,
                            GroovyTemplateService groovyTemplateService,
                            GroovySafeService groovySafeService) {
        this.groovyEvalService = groovyEvalService;
        this.groovyTemplateService = groovyTemplateService;
        this.groovySafeService = groovySafeService;
    }

    /** 执行用户提交的 Groovy 脚本。 */
    @PostMapping("/groovy/eval")
    public String eval(@RequestParam("script") String script) throws Exception {
        return groovyEvalService.evaluate(script);
    }

    /** 把用户提交的 Groovy 源码加载为类。 */
    @PostMapping("/groovy/load")
    public String load(@RequestParam("src") String src) throws Exception {
        return groovyEvalService.loadClass(src);
    }

    /** 渲染用户提交的 Groovy 模板。 */
    @PostMapping("/groovy/template")
    public String template(@RequestParam("tpl") String tpl) throws Exception {
        return groovyTemplateService.render(tpl);
    }

    /** 安全对照：用 SecureASTCustomizer 白名单执行。 */
    @GetMapping("/groovy/safe")
    public String safe() throws Exception {
        return groovySafeService.evaluateWithWhitelist();
    }
}
