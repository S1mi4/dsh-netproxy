package com.demo.svc;

import groovy.text.GStringTemplateEngine;
import groovy.text.TemplateEngine;
import java.util.HashMap;

/**
 * Groovy 模板渲染层。
 */
public class GroovyTemplateService {

    /** 高危：模板内容来自请求参数 → SSTI → RCE。 */
    public String render(String tpl) throws Exception {
        TemplateEngine engine = new GStringTemplateEngine();   // SNK-8 sink
        Object out = engine.createTemplate(tpl).make(new HashMap<>()).toString();
        return String.valueOf(out);
    }
}
