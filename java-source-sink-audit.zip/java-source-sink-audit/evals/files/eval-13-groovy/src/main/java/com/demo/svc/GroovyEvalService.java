package com.demo.svc;

import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyShell;

/**
 * Groovy 脚本执行层。
 */
public class GroovyEvalService {

    /** 高危：脚本内容来自请求参数 → GroovyShell 直接执行 → RCE。 */
    public String evaluate(String script) throws Exception {
        GroovyShell shell = new GroovyShell();          // SNK-8 sink
        Object result = shell.evaluate(script);          // SNK-8 sink
        return String.valueOf(result);
    }

    /** 高危：Groovy 源码来自请求参数 → parseClass 加载为类（等价 defineClass）。 */
    public String loadClass(String src) {
        GroovyClassLoader loader = new GroovyClassLoader();   // SNK-8 sink
        Class<?> clazz = loader.parseClass(src);              // SNK-8 sink
        return clazz.getName();
    }
}
