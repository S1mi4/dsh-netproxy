package com.demo.legacy;

import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.Expression;

/**
 * 范围外代码：裸 SpEL 表达式不在本技能范围（SNK-8 仅覆盖 Groovy 脚本 / 模板入口）。
 * 审计时若遇到此类代码，应忽略，不得列为发现。
 */
public class LegacySpelBean {

    public Object eval(String expr) {
        SpelExpressionParser parser = new SpelExpressionParser();
        Expression expression = parser.parseExpression(expr);   // 范围外：裸 SpEL，不报告
        return expression.getValue();
    }
}
