package com.demo.svc;

import com.demo.engine.WorkflowEngineFacade;
import com.demo.engine.WorkflowSafeFacade;
import java.io.InputStream;

/**
 * 工作流业务层：把请求参数传递到引擎执行层。
 */
public class WorkflowService {

    private final WorkflowEngineFacade engineFacade;
    private final WorkflowSafeFacade safeFacade;

    public WorkflowService(WorkflowEngineFacade engineFacade, WorkflowSafeFacade safeFacade) {
        this.engineFacade = engineFacade;
        this.safeFacade = safeFacade;
    }

    public String executeScript(String script, String lang) throws Exception {
        return engineFacade.evalScript(script, lang);
    }

    public String executeDelegateExpression(String expr) throws Exception {
        return engineFacade.invokeDelegateExpression(expr);
    }

    public String deployProcess(String name, InputStream in) {
        return engineFacade.deploy(name, in);
    }

    /** 安全对照：调用固定流程定义部署。 */
    public String deployFixed() {
        return safeFacade.deployFixedProcess();
    }
}
