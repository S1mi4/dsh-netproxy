package com.demo.engine;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.impl.el.ExpressionManager;
import org.activiti.engine.impl.scripting.ScriptingEngines;
import java.io.InputStream;

/**
 * 引擎执行层：直接调用 Activiti/Flowable 的表达式 / 脚本 / 部署 API。
 */
public class WorkflowEngineFacade {

    private final ExpressionManager expressionManager;
    private final ScriptingEngines scriptingEngines;
    private final RepositoryService repositoryService;

    public WorkflowEngineFacade(ExpressionManager expressionManager,
                                ScriptingEngines scriptingEngines,
                                RepositoryService repositoryService) {
        this.expressionManager = expressionManager;
        this.scriptingEngines = scriptingEngines;
        this.repositoryService = repositoryService;
    }

    /** 高危：脚本内容来自请求参数，无语言白名单 → 任意代码执行。 */
    public String evalScript(String script, String lang) throws Exception {
        Object result = scriptingEngines.eval(script, lang);   // SNK-4 sink
        return String.valueOf(result);
    }

    /** 高危：delegateExpression 来自请求参数 → 触发任意类加载并实例化。 */
    public String invokeDelegateExpression(String expr) throws Exception {
        Expression expression = expressionManager.createExpression(expr);  // SNK-4 sink
        Object target = expression.getValue(null);                        // SNK-4 sink
        ((JavaDelegate) target).execute(null);
        return "ok";
    }

    /** 高危：部署用户上传的 BPMN（流程定义内容受控 → 表达式/脚本/委派受控）。 */
    public String deploy(String name, InputStream in) {
        return repositoryService.createDeployment()   // SNK-4 sink
                .addInputStream(name, in)
                .deploy();
    }
}
