package com.demo.engine;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.impl.el.ExpressionManager;
import java.io.InputStream;

/**
 * 安全对照：固定流程定义、常量表达式。
 */
public class WorkflowSafeFacade {

    private final ExpressionManager expressionManager;
    private final RepositoryService repositoryService;

    public WorkflowSafeFacade(ExpressionManager expressionManager,
                              RepositoryService repositoryService) {
        this.expressionManager = expressionManager;
        this.repositoryService = repositoryService;
    }

    /** Info：常量表达式，字面量求值，非漏洞。 */
    public String evalConstant() {
        Expression expression = expressionManager.createExpression("#{true}");  // SNK-4 Info
        return String.valueOf(expression.getValue(null));
    }

    /** Info：部署固定内置流程定义（资源来自 classpath，非用户输入）。 */
    public String deployFixedProcess() {
        InputStream in = getClass().getResourceAsStream("/processes/standard.bpmn");
        return repositoryService.createDeployment()   // SNK-4 Info
                .addInputStream("standard.bpmn", in)
                .deploy();
    }
}
