package com.demo.web;

import com.demo.svc.WorkflowService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.InputStream;

/**
 * 工作流引擎入口（Activiti/Flowable 风格）。
 */
@RestController
public class WorkflowController {

    private final WorkflowService workflowService;

    public WorkflowController(WorkflowService workflowService) {
        this.workflowService = workflowService;
    }

    /** 执行用户提供的脚本任务脚本内容。 */
    @PostMapping("/wf/script")
    public String runScript(@RequestParam("script") String script,
                            @RequestParam("lang") String lang) throws Exception {
        return workflowService.executeScript(script, lang);
    }

    /** 用用户提供的表达式执行服务任务（可触发 delegateExpression 类加载）。 */
    @GetMapping("/wf/delegate")
    public String runDelegate(@RequestParam("expr") String expr) throws Exception {
        return workflowService.executeDelegateExpression(expr);
    }

    /** 部署用户上传的 BPMN 流程定义。 */
    @PostMapping("/wf/deploy")
    public String deploy(@RequestParam("file") MultipartFile file) throws Exception {
        String name = file.getOriginalFilename();
        InputStream in = file.getInputStream();
        return workflowService.deployProcess(name, in);
    }
}
