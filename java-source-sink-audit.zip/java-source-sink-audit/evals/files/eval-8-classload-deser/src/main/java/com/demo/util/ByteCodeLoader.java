package com.demo.util;

import java.lang.reflect.Method;

/**
 * 字节码定义工具。
 */
public class ByteCodeLoader extends ClassLoader {

    /**
     * 将外部传入的字节码定义为类。
     */
    public Class<?> defineExternalClass(byte[] bytes) {
        return defineClass(null, bytes, 0, bytes.length);
    }

    /**
     * 将配置类名 + 固定字节码定义为类（安全对照：字节来源固定）。
     */
    public Class<?> defineConfigClass(byte[] bytes) throws Exception {
        Class<?> clazz = defineClass("com.demo.config.ConfigBean", bytes, 0, bytes.length);
        Method m = clazz.getMethod("load");
        m.invoke(clazz.getDeclaredConstructor().newInstance());
        return clazz;
    }
}