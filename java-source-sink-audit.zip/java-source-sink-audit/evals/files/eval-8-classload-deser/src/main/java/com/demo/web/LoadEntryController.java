package com.demo.web;

import com.demo.svc.ClassDispatchService;
import com.demo.svc.SessionImportService;
import com.demo.util.ByteCodeLoader;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * 类加载与反序列化入口。
 */
@RestController
public class LoadEntryController {

    private final ClassDispatchService classDispatchService;
    private final SessionImportService sessionImportService;

    public LoadEntryController(ClassDispatchService classDispatchService,
                               SessionImportService sessionImportService) {
        this.classDispatchService = classDispatchService;
        this.sessionImportService = sessionImportService;
    }

    /**
     * 按名称加载并执行一个任务类。
     */
    @GetMapping("/task/load")
    public String loadTask(@RequestParam("taskClass") String taskClass) throws Exception {
        return classDispatchService.dispatch(taskClass);
    }

    /**
     * 按名称加载并执行一个插件。
     */
    @GetMapping("/plugin/load")
    public String loadPlugin(@RequestParam("pluginClass") String pluginClass) throws Exception {
        return classDispatchService.runPlugin(pluginClass);
    }

    /**
     * 导入会话数据（二进制序列化格式）。
     */
    @PostMapping("/session/import")
    public String importSession(@RequestBody byte[] body) throws Exception {
        return sessionImportService.importSession(body);
    }

    /**
     * 接收字节码并直接定义为类执行。
     */
    @PostMapping("/code/define")
    public String defineCode(@RequestBody byte[] body) throws Exception {
        return new ByteCodeLoader().defineExternalClass(body).getName();
    }
}