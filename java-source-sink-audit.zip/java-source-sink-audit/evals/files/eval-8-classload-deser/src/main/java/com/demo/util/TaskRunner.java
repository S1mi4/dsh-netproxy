package com.demo.util;

/**
 * 任务执行器。
 */
public class TaskRunner {

    /**
     * 通过类加载器加载并实例化任务类：类名来自外部输入。
     */
    public String run(String taskClassName) throws Exception {
        Class<?> clazz = getClass().getClassLoader().loadClass(taskClassName);
        Object instance = clazz.getDeclaredConstructor().newInstance();
        return instance.toString();
    }
}