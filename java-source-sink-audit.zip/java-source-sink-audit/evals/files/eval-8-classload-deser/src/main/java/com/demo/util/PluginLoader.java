package com.demo.util;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * 插件加载器。
 */
public class PluginLoader {

    /**
     * 从给定目录加载插件类并运行。
     */
    public String loadAndRun(String pluginClassName) throws Exception {
        URLClassLoader loader = new URLClassLoader(new URL[]{new URL("file:///app/plugins")});
        Class<?> clazz = loader.loadClass(pluginClassName);
        return ((Runnable) clazz.getDeclaredConstructor().newInstance()).toString();
    }

    /**
     * 常量插件类（安全对照）。
     */
    public String loadFixedPlugin() throws Exception {
        URLClassLoader loader = new URLClassLoader(new URL[]{new URL("file:///app/plugins")});
        Class<?> clazz = loader.loadClass("com.demo.plugins.audit.AuditPlugin");
        return clazz.getName();
    }
}