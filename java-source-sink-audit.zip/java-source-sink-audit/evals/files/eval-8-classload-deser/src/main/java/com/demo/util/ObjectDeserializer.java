package com.demo.util;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;

/**
 * 对象反序列化工具。
 */
public class ObjectDeserializer {

    /**
     * 将字节流反序列化为对象：数据来自外部输入，无任何过滤。
     */
    public Object read(byte[] data) throws Exception {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data))) {
            return ois.readObject();
        }
    }

    /**
     * 带 ObjectInputFilter 白名单的反序列化（安全对照）。
     */
    public Object readFiltered(byte[] data) throws Exception {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data))) {
            ois.setObjectInputFilter(filterInfo -> {
                if (filterInfo.serialClass() == null) {
                    return ObjectInputFilter.Status.ALLOWED;
                }
                String name = filterInfo.serialClass().getName();
                if (name.startsWith("com.demo.session.")) {
                    return ObjectInputFilter.Status.ALLOWED;
                }
                return ObjectInputFilter.Status.REJECTED;
            });
            return ois.readObject();
        }
    }
}