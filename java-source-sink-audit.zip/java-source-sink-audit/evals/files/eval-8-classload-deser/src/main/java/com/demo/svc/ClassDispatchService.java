package com.demo.svc;

import com.demo.util.PluginLoader;
import com.demo.util.TaskRunner;

/**
 * 类加载分发服务（跨类调用链）。
 */
public class ClassDispatchService {

    private final TaskRunner taskRunner;
    private final PluginLoader pluginLoader;

    public ClassDispatchService(TaskRunner taskRunner, PluginLoader pluginLoader) {
        this.taskRunner = taskRunner;
        this.pluginLoader = pluginLoader;
    }

    /**
     * 调度任务类。
     */
    public String dispatch(String taskClass) throws Exception {
        return taskRunner.run(taskClass);
    }

    /**
     * 加载并运行插件。
     */
    public String runPlugin(String pluginClass) throws Exception {
        return pluginLoader.loadAndRun(pluginClass);
    }
}