package com.demo.svc;

import com.demo.util.ObjectDeserializer;

/**
 * 会话导入服务。
 */
public class SessionImportService {

    private final ObjectDeserializer objectDeserializer;

    public SessionImportService(ObjectDeserializer objectDeserializer) {
        this.objectDeserializer = objectDeserializer;
    }

    /**
     * 导入会话数据。
     */
    public String importSession(byte[] payload) throws Exception {
        Object obj = objectDeserializer.read(payload);
        return obj.toString();
    }
}