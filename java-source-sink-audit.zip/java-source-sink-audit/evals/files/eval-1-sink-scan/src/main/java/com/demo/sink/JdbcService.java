package com.demo.sink;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * JDBC 连接相关代码。
 */
public class JdbcService {

    /**
     * 使用配置的 JDBC URL 建立连接。jdbcUrl 由前端传入。
     */
    public ResultSet queryByUrl(String jdbcUrl, String username, String password) throws Exception {
        Connection conn = DriverManager.getConnection(jdbcUrl, username, password);
        Statement stmt = conn.createStatement();
        return stmt.executeQuery("select 1");
    }

    /**
     * 内部固定连接。
     */
    public Connection fixedConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
                "jdbc:mysql://10.0.0.8:3306/db?useSSL=false",
                "app", "secret");
    }

    /**
     * 通过驱动管理器 connect 建立连接，URL 来自用户输入。
     */
    public Connection connectViaDriverManager(String url, java.util.Properties props) throws Exception {
        return DriverManager.connect(url, props);
    }
}