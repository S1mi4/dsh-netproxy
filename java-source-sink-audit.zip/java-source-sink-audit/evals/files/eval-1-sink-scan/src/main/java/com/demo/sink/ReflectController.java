package com.demo.sink;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.naming.InitialContext;

/**
 * 反射相关入口。
 */
@RestController
public class ReflectController {

    /**
     * 根据前端传入的类名加载类。
     */
    @GetMapping("/reflect/load")
    public String loadClass(@RequestParam("className") String className) throws Exception {
        Class<?> clazz = Class.forName(className);
        return clazz.getName();
    }

    /**
     * 根据前端传入的类名加载类并实例化。
     */
    @GetMapping("/reflect/new")
    public String newInstance(@RequestParam("className") String className) throws Exception {
        Object instance = Class.forName(className, true, Thread.currentThread().getContextClassLoader())
                .getDeclaredConstructor().newInstance();
        return instance.toString();
    }

    /**
     * 从 JNDI 获取一个服务类。
     */
    @GetMapping("/reflect/jndi")
    public Object lookup(@RequestParam("jndiName") String jndiName) throws Exception {
        return new InitialContext().lookup(jndiName);
    }
}