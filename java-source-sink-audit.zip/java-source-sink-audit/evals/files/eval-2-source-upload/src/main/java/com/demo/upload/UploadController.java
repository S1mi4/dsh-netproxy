package com.demo.upload;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * 文件上传接口。
 */
@RestController
public class UploadController {

    private static final List<String> ALLOWED_EXT = Arrays.asList("jpg", "png", "gif");
    private static final String UPLOAD_DIR = "/var/upload";

    /**
     * 通用上传接口，保存到服务器。
     */
    @PostMapping("/upload/generic")
    public String uploadGeneric(@RequestParam("file") MultipartFile file) throws IOException {
        String original = file.getOriginalFilename();
        File target = new File(UPLOAD_DIR, original);
        file.transferTo(target);
        return target.getAbsolutePath();
    }

    /**
     * 图片上传接口，仅校验 ContentType，不校验扩展名。
     */
    @PostMapping("/upload/image")
    public String uploadImage(@RequestParam("file") MultipartFile file) throws IOException {
        String contentType = file.getContentType();
        if (contentType != null && !contentType.startsWith("image/")) {
            throw new IllegalArgumentException("only image allowed");
        }
        String original = file.getOriginalFilename();
        file.transferTo(new File(UPLOAD_DIR, original));
        return "ok";
    }

    /**
     * 头像上传，白名单校验扩展名（安全对照）。
     */
    @PostMapping("/upload/avatar")
    public String uploadAvatar(@RequestParam("file") MultipartFile file) throws IOException {
        String original = file.getOriginalFilename();
        String ext = original.substring(original.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
        if (!ALLOWED_EXT.contains(ext)) {
            throw new IllegalArgumentException("extension not allowed");
        }
        file.transferTo(new File(UPLOAD_DIR, original));
        return "ok";
    }

    /**
     * 流式写盘上传，文件名来自前端。
     */
    @PostMapping("/upload/stream")
    public String uploadStream(@RequestParam("file") MultipartFile file) throws IOException {
        String original = file.getOriginalFilename();
        Files.copy(file.getInputStream(), Paths.get(UPLOAD_DIR, original));
        return "ok";
    }
}