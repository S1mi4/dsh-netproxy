package com.demo.upload;

import java.io.IOException;
import java.io.InputStream;

/**
 * 类路径资源加载。
 */
public class ResourceLoader {

    /**
     * 加载用户指定的资源：资源名来自请求参数。
     */
    public InputStream loadUserResource(String resourceName) throws IOException {
        return getClass().getResourceAsStream(resourceName);
    }

    /**
     * 加载用户指定的资源（类加载器方式）：资源名来自请求参数。
     */
    public InputStream loadUserResourceByClassLoader(String resourceName) {
        return Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceName);
    }

    /**
     * 加载配置资源，固定路径（安全对照）。
     */
    public InputStream loadConfig() {
        return getClass().getResourceAsStream("/config/app.properties");
    }
}