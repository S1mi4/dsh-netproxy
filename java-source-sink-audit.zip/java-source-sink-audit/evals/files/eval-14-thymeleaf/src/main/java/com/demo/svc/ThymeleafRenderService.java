package com.demo.svc;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

/**
 * Thymeleaf 模板渲染层。
 */
public class ThymeleafRenderService {

    private final TemplateEngine templateEngine;

    public ThymeleafRenderService(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }

    /** 高危：模板内容来自请求体 → TemplateEngine.process 求值 ${...}（SpEL）→ RCE。 */
    public String render(String template) {
        Context context = new Context();
        return templateEngine.process(template, context);   // SNK-9 sink
    }
}
