package com.demo.web;

import com.demo.svc.ThymeleafRenderService;
import org.springframework.web.bind.annotation.*;

/**
 * Thymeleaf 视图与模板渲染入口。
 */
@RestController
public class ThymeleafController {

    private final ThymeleafRenderService thymeleafRenderService;

    public ThymeleafController(ThymeleafRenderService thymeleafRenderService) {
        this.thymeleafRenderService = thymeleafRenderService;
    }

    /** 高危：视图名来自 @PathVariable → 视图名注入 SSTI（__${...}__ 触发 SpEL 求值）。 */
    @GetMapping("/view/{name}")
    public String render(@PathVariable("name") String viewName) {
        return viewName;   // SNK-9 sink：返回用户可控的视图名
    }

    /** 高危：渲染用户提交的模板内容 → 求值 ${...}（SpEL）→ RCE。 */
    @PostMapping("/thymeleaf/render")
    public String renderTemplate(@RequestBody String template) {
        return thymeleafRenderService.render(template);
    }

    /** Info：返回固定常量视图名。 */
    @GetMapping("/welcome")
    public String welcome() {
        return "welcome";   // SNK-9 Info：常量视图名
    }
}
