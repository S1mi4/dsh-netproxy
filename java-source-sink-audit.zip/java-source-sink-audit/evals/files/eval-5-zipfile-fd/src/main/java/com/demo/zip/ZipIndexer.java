package com.demo.zip;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipFile;

/**
 * ZIP 文档索引器：为每个注册的文档保留一个句柄。
 */
public class ZipIndexer {

    /** 已注册文档的句柄列表（仅供统计，从不清除）。 */
    private final List<ZipFile> registered = new ArrayList<>();
    private int indexCount;

    /**
     * 注册一个 ZIP 文档：打开句柄并保存到 registered（从不关闭）。
     */
    public void register(String docPath) throws IOException {
        ZipFile zf = new ZipFile(docPath);
        registered.add(zf);
        indexCount++;
    }

    /**
     * 统计已注册文档数。
     */
    public int registeredCount() {
        return indexCount;
    }

    /**
     * 受控注册：用完立即关闭（try-with-resources，安全对照）。
     */
    public int indexEntries(String docPath) throws IOException {
        int count = 0;
        try (ZipFile zf = new ZipFile(docPath)) {
            count = zf.size();
        }
        return count;
    }
}