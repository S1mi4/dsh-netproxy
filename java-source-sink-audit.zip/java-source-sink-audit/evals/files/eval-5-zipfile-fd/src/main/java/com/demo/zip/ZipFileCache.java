package com.demo.zip;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 缓存打开的 ZIP 文件句柄，避免重复打开。
 */
public class ZipFileCache {

    /** 按路径缓存 ZipFile 实例。 */
    private final Map<String, ZipFile> cache = new ConcurrentHashMap<>();

    /**
     * 打开（或从缓存取出）ZIP 文件。路径由前端传入。
     */
    public ZipFile get(String zipPath) throws IOException {
        ZipFile zf = cache.get(zipPath);
        if (zf == null) {
            zf = new ZipFile(zipPath);
            cache.put(zipPath, zf);
        }
        return zf;
    }

    /**
     * 读取 ZIP 内指定条目的内容。zipPath 来自请求参数。
     */
    public byte[] readEntry(String zipPath, String entryName) throws IOException {
        ZipFile zf = get(zipPath);
        ZipEntry entry = zf.getEntry(entryName);
        if (entry == null) {
            return new byte[0];
        }
        try (var in = zf.getInputStream(entry)) {
            return in.readAllBytes();
        }
    }

    /**
     * 直接打开读取，用完即关（try-with-resources，安全对照）。
     */
    public byte[] readEntrySafe(String zipPath, String entryName) throws IOException {
        try (ZipFile zf = new ZipFile(zipPath)) {
            ZipEntry entry = zf.getEntry(entryName);
            if (entry == null) {
                return new byte[0];
            }
            try (var in = zf.getInputStream(entry)) {
                return in.readAllBytes();
            }
        }
    }
}