package com.demo.ssrf;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 只强转 HttpURLConnection、无主机白名单的实例。
 */
public class HttpFetcher {

    /**
     * 强制转换 HttpURLConnection，但没有主机白名单。
     */
    public String fetch(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(3000);
        try (var in = conn.getInputStream()) {
            return new String(in.readAllBytes());
        }
    }
}