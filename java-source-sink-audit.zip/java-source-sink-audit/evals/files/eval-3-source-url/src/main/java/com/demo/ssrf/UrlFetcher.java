package com.demo.ssrf;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * URL 抓取工具。
 */
public class UrlFetcher {

    /**
     * 抓取用户传入的 URL 内容。
     */
    public String fetch(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        try (InputStream in = url.openStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * 用 openConnection 获取输入流。
     */
    public String fetchWithOpenConnection(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        try (InputStream in = url.openConnection().getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * 安全对照：强制转换为 HttpURLConnection 并做协议与主机白名单校验。
     */
    public String fetchSafely(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        if (!"http".equalsIgnoreCase(url.getProtocol()) && !"https".equalsIgnoreCase(url.getProtocol())) {
            throw new IllegalArgumentException("protocol not allowed");
        }
        if (!"api.example.com".equals(url.getHost())) {
            throw new IllegalArgumentException("host not allowed");
        }
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try (InputStream in = conn.getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}