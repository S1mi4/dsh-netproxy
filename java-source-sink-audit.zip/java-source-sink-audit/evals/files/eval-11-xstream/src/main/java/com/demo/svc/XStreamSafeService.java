package com.demo.svc;

import com.thoughtworks.xstream.XStream;

/**
 * 安全对照：setupDefaultSecurity + allowTypes 精确白名单。
 */
public class XStreamSafeService {

    public String fromXmlSafe() {
        XStream xstream = new XStream();                 // SNK-6 Info
        XStream.setupDefaultSecurity(xstream);             // 默认安全框架
        xstream.allowTypes(new Class[]{ Config.class });  // 类名白名单
        Object obj = xstream.fromXML("<com.demo.svc.XStreamSafeService_Config><name>demo</name></com.demo.svc.XStreamSafeService_Config>");
        return String.valueOf(obj);
    }

    public static class Config {
        String name;
    }
}
