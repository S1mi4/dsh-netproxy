package com.demo.legacy;

import java.sql.Connection;
import java.sql.Statement;

/**
 * 范围外代码：SQL 注入不在本技能范围（SNK-6 仅覆盖 XStream 反序列化）。
 * 审计时若遇到此类代码，应忽略，不得列为发现。
 */
public class LegacySqlDao {

    public void query(Connection conn, String name) throws Exception {
        Statement stmt = conn.createStatement();
        stmt.executeQuery("SELECT * FROM users WHERE name='" + name + "'");  // 范围外：SQL 注入，不报告
    }
}
