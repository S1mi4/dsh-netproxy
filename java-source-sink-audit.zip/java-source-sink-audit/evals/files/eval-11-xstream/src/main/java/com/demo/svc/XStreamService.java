package com.demo.svc;

import com.demo.engine.XStreamEngine;

/**
 * XStream 业务层：把请求体传递到引擎层。
 */
public class XStreamService {

    private final XStreamEngine xStreamEngine;

    public XStreamService(XStreamEngine xStreamEngine) {
        this.xStreamEngine = xStreamEngine;
    }

    public String fromXml(String xml) {
        return xStreamEngine.fromXml(xml);   // 参数传递
    }
}
