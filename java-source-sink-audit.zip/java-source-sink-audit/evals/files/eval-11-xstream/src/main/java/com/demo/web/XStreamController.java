package com.demo.web;

import com.demo.svc.XStreamService;
import com.demo.svc.XStreamSafeService;
import org.springframework.web.bind.annotation.*;

/**
 * XStream 反序列化入口。
 */
@RestController
public class XStreamController {

    private final XStreamService xStreamService;
    private final XStreamSafeService xStreamSafeService;

    public XStreamController(XStreamService xStreamService, XStreamSafeService xStreamSafeService) {
        this.xStreamService = xStreamService;
        this.xStreamSafeService = xStreamSafeService;
    }

    /** 反序列化用户提交的 XML。 */
    @PostMapping("/xstream/parse")
    public String parse(@RequestBody String xml) throws Exception {
        return xStreamService.fromXml(xml);
    }

    /** 安全对照：用白名单配置反序列化。 */
    @GetMapping("/xstream/safe")
    public String parseSafe() throws Exception {
        return xStreamSafeService.fromXmlSafe();
    }
}
