package com.demo.engine;

import com.thoughtworks.xstream.XStream;

/**
 * XStream 引擎层。
 */
public class XStreamEngine {

    /** 高危：无 allowTypes 白名单，XML 可实例化任意类并触发其方法 → RCE。 */
    public String fromXml(String xml) {
        XStream xstream = new XStream();        // SNK-6 sink
        Object obj = xstream.fromXML(xml);      // SNK-6 sink
        return String.valueOf(obj);
    }
}
