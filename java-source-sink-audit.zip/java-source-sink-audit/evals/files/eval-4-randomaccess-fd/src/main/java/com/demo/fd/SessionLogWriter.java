package com.demo.fd;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 日志写入器：为每个会话保留一个句柄。
 */
public class SessionLogWriter {

    /** 历史会话句柄列表（仅供统计，从不清除）。 */
    private final List<RandomAccessFile> history = new ArrayList<>();
    private final AtomicLong writeCount = new AtomicLong();

    /**
     * 为每一次写入新建句柄并保存到 history（从不关闭）。
     */
    public void append(String sessionId, String line) throws IOException {
        RandomAccessFile raf = new RandomAccessFile("/var/log/sessions/" + sessionId + ".log", "rw");
        raf.seek(raf.length());
        raf.write((line + "\n").getBytes());
        history.add(raf);
        writeCount.incrementAndGet();
    }

    /**
     * 统计写入了多少会话（遍历 history）。
     */
    public long sessionCount() {
        return writeCount.get();
    }

    /**
     * 受控写入：用 try-with-resources 立刻关闭（安全对照）。
     */
    public void appendControlled(String sessionId, String line) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile("/var/log/sessions/" + sessionId + ".log", "rw")) {
            raf.seek(raf.length());
            raf.write((line + "\n").getBytes());
        }
    }
}