package com.demo.fd;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 通过 RandomAccessFile 读写文件的工具。
 */
public class RandomAccessFileCache {

    /** 缓存打开的 RandomAccessFile，复用句柄。 */
    private final Map<String, RandomAccessFile> cache = new ConcurrentHashMap<>();

    /**
     * 打开（或从缓存取出）文件句柄。文件路径由前端传入。
     */
    public RandomAccessFile get(String filePath) throws IOException {
        RandomAccessFile raf = cache.get(filePath);
        if (raf == null) {
            raf = new RandomAccessFile(filePath, "rw");
            cache.put(filePath, raf);
        }
        return raf;
    }

    /**
     * 读取文件指定偏移的内容。文件路径来自请求参数。
     */
    public byte[] readSegment(String filePath, long offset, int length) throws IOException {
        RandomAccessFile raf = get(filePath);
        raf.seek(offset);
        byte[] buf = new byte[length];
        raf.read(buf);
        return buf;
    }

    /**
     * 直接打开文件读取，用完即关（try-with-resources，安全对照）。
     */
    public byte[] readSegmentSafe(String filePath, long offset, int length) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(filePath, "r")) {
            raf.seek(offset);
            byte[] buf = new byte[length];
            raf.read(buf);
            return buf;
        }
    }

    /**
     * 扩展名白名单校验后读取（安全对照）：路径受限且用完即关。
     */
    public byte[] readImageSegment(String fileName, long offset, int length) throws IOException {
        if (!fileName.endsWith(".jpg") && !fileName.endsWith(".png")) {
            throw new IllegalArgumentException("not an image");
        }
        try (RandomAccessFile raf = new RandomAccessFile("/var/data/images/" + fileName, "r")) {
            raf.seek(offset);
            byte[] buf = new byte[length];
            raf.read(buf);
            return buf;
        }
    }
}