package com.demo.dao;

/**
 * 类名到 Class 对象的映射查询。
 */
public class ClassRepository {

    /**
     * 按名称查找类。
     */
    public Class<?> findByName(String name) throws ClassNotFoundException {
        return Class.forName(name);
    }
}