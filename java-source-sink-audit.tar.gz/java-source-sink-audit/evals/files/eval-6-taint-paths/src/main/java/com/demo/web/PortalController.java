package com.demo.web;

import com.demo.service.ClassLoadService;
import com.demo.service.UploadService;
import com.demo.service.UrlFetchService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * 对外 HTTP 入口。
 */
@RestController
public class PortalController {

    private final ClassLoadService classLoadService;
    private final UploadService uploadService;
    private final UrlFetchService urlFetchService;

    public PortalController(ClassLoadService classLoadService, UploadService uploadService,
                            UrlFetchService urlFetchService) {
        this.classLoadService = classLoadService;
        this.uploadService = uploadService;
        this.urlFetchService = urlFetchService;
    }

    /**
     * 加载指定类。
     */
    @GetMapping("/class/load")
    public String loadClass(@RequestParam("name") String name) throws Exception {
        return classLoadService.loadAndDescribe(name);
    }

    /**
     * 上传文件。
     */
    @PostMapping("/file/upload")
    public String upload(@RequestParam("file") MultipartFile file) throws Exception {
        return uploadService.save(file);
    }

    /**
     * 抓取指定 URL 内容。
     */
    @GetMapping("/proxy/fetch")
    public String fetch(@RequestParam("url") String url) throws Exception {
        return urlFetchService.fetchContent(url);
    }
}