package com.demo.dao;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * 文件落盘。
 */
public class FileStoreDao {

    /**
     * 将上传内容写入服务器磁盘。
     */
    public String persist(String originalName, InputStream content) throws Exception {
        Files.copy(content, Paths.get("/var/webroot/uploads/", originalName));
        return originalName;
    }
}