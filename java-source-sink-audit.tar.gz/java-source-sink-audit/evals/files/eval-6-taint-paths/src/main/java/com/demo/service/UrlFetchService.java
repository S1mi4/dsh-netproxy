package com.demo.service;

import com.demo.util.UrlReader;

/**
 * URL 抓取业务服务。
 */
public class UrlFetchService {

    private final UrlReader urlReader;

    public UrlFetchService(UrlReader urlReader) {
        this.urlReader = urlReader;
    }

    /**
     * 抓取 URL 内容并返回。
     */
    public String fetchContent(String targetUrl) throws Exception {
        String normalized = targetUrl.trim();
        return urlReader.read(normalized);
    }
}