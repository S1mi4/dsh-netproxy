package com.demo.util;

import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * URL 内容读取工具。
 */
public class UrlReader {

    /**
     * 直接读取 URL 内容。
     */
    public String read(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        try (InputStream in = url.openStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}