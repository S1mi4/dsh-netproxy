package com.demo.service;

import com.demo.dao.ClassRepository;

/**
 * 类加载业务服务。
 */
public class ClassLoadService {

    private final ClassRepository classRepository;

    public ClassLoadService(ClassRepository classRepository) {
        this.classRepository = classRepository;
    }

    /**
     * 加载并描述一个类。
     */
    public String loadAndDescribe(String className) throws Exception {
        Class<?> clazz = classRepository.findByName(className);
        return clazz.getName();
    }
}