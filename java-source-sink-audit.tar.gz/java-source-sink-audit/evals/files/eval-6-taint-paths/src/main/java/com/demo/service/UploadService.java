package com.demo.service;

import com.demo.dao.FileStoreDao;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * 上传业务服务。
 */
@Service
public class UploadService {

    private final FileStoreDao fileStoreDao;

    public UploadService(FileStoreDao fileStoreDao) {
        this.fileStoreDao = fileStoreDao;
    }

    /**
     * 保存上传文件。
     */
    public String save(MultipartFile file) throws Exception {
        String fileName = file.getOriginalFilename();
        return fileStoreDao.persist(fileName, file.getInputStream());
    }
}