package com.demo.impl;

import com.demo.svc.AuthService;

/**
 * 基于本地内存的认证实现。
 */
public class MemoryAuthService implements AuthService {

    /**
     * 直接比对 token。
     */
    @Override
    public String authenticate(String token) {
        if ("admin-token".equals(token)) {
            return "admin";
        }
        return "anonymous";
    }
}