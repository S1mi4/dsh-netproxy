package com.demo.impl;

import com.demo.svc.AuthService;

/**
 * 基于插件的认证实现：根据 token 中的类名动态加载认证器。
 */
public class PluginAuthService implements AuthService {

    /**
     * 从 token 中解析出认证器类名并加载。
     */
    @Override
    public String authenticate(String token) {
        String className = token.split(":")[0];
        try {
            Class<?> clazz = Class.forName(className);
            return clazz.getSimpleName();
        } catch (ClassNotFoundException e) {
            return "unknown";
        }
    }
}