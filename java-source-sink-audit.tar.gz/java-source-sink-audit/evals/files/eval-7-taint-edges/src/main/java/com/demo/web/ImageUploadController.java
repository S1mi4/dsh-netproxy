package com.demo.web;

import com.demo.impl.MemoryAuthService;

/**
 * 图片上传入口（白名单版本）。
 */
public class ImageUploadController {

    private static final String[] ALLOWED = {"jpg", "png", "gif"};

    /**
     * 校验扩展名后保存。
     */
    public String saveImage(String fileName, byte[] content) throws Exception {
        String ext = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        boolean ok = false;
        for (String allowed : ALLOWED) {
            if (allowed.equals(ext)) {
                ok = true;
                break;
            }
        }
        if (!ok) {
            throw new IllegalArgumentException("extension not allowed");
        }
        try (java.io.FileOutputStream fos = new java.io.FileOutputStream("/var/data/images/" + fileName)) {
            fos.write(content);
        }
        return "/images/" + fileName;
    }

    /**
     * 复习用：直接部署内存认证，无外部依赖。
     */
    public String demoLogin(String token) {
        return new MemoryAuthService().authenticate(token);
    }
}