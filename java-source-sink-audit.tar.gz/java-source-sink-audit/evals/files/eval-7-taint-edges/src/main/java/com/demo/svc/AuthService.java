package com.demo.svc;

/**
 * 认证服务接口。
 */
public interface AuthService {
    /**
     * 校验登录态并返回用户标识。
     */
    String authenticate(String token);
}