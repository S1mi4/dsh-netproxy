package com.demo.util;

import javax.naming.InitialContext;

/**
 * 从 JNDI 读取配置的工具。
 */
public class JndiConfigLoader {

    /**
     * 从 JNDI 读取配置值并加载对应类。
     * 注意：InitialContext.lookup 属于本技能范围外的 JNDI 注入点，此处仅作为
     * 数据传递节点（读取配置值），不作为独立发现报告。
     */
    public Class<?> loadClassFromConfig(String configKey) throws Exception {
        String className = String.valueOf(new InitialContext().lookup(configKey));
        return Class.forName(className);
    }
}