package com.demo.web;

import com.demo.util.JndiConfigLoader;

/**
 * 从 JNDI 配置加载类名入口。
 */
public class JndiConfigController {

    private final JndiConfigLoader jndiConfigLoader;

    public JndiConfigController(JndiConfigLoader jndiConfigLoader) {
        this.jndiConfigLoader = jndiConfigLoader;
    }

    /**
     * 根据配置 key 加载类。
     */
    public String loadByKey(String configKey) throws Exception {
        return jndiConfigLoader.loadClassFromConfig(configKey).getName();
    }
}