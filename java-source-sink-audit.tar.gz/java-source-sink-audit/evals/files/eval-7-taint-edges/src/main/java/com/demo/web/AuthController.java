package com.demo.web;

import com.demo.svc.AuthService;

/**
 * 登录入口。
 */
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * 使用请求头中的 token 完成认证。
     */
    public String login(String authToken) {
        return authService.authenticate(authToken);
    }
}