package com.demo.web;

import java.io.FileOutputStream;

/**
 * 附件上传入口（黑名单版本）。
 */
public class AttachmentUploadController {

    private static final String[] BLACKLIST = {"jsp", "jspx", "war"};

    /**
     * 黑名单过滤后保存：可被 .jsp.jpg / 大小写 / %00 绕过。
     */
    public String saveAttachment(String fileName, byte[] content) throws Exception {
        String ext = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        boolean banned = false;
        for (String bad : BLACKLIST) {
            if (bad.equals(ext)) {
                banned = true;
                break;
            }
        }
        if (banned) {
            throw new IllegalArgumentException("extension banned");
        }
        try (FileOutputStream fos = new FileOutputStream("/var/webroot/attach/" + fileName)) {
            fos.write(content);
        }
        return "/attach/" + fileName;
    }
}