package com.demo.legacy;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * 遗留数据库工具（未被任何入口调用）。
 */
public class LegacyDbTool {

    /**
     * 建立连接。该方法在当前代码库中没有任何调用方。
     */
    public Connection connect(String jdbcUrl) throws Exception {
        return DriverManager.getConnection(jdbcUrl, "root", "pass");
    }

    /**
     * 供内部定时任务调用的固定连接。
     */
    public Connection connectFixed() throws Exception {
        return DriverManager.getConnection("jdbc:mysql://10.1.1.5:3306/report", "report", "pass");
    }
}