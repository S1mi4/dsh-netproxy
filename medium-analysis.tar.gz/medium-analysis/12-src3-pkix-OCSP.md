# 12. [Source/SRC-3] OCSP responder URL（证书 AIA → SSRF）— OCSP

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（URL → HttpURLConnection，无主机白名单） |
| 严重级别 | Medium（开启 OCSP 校验 + 校验攻击者证书时触发） |
| 位置 | `java.base/sun/security/provider/certpath/OCSP.java:284,292`（`(HttpURLConnection)url.openConnection()`，GET/POST 两条路径）；来源 `OCSP.java:342-373`（`getResponderURI` 读取证书 AIA 扩展） |
| 模块 | java.base（PKIX 证书路径校验） |

## 1. 在 JDK 中的作用

OCSP（在线证书状态协议）是 PKIX 证书撤销检查的一种方式：校验证书链时向"OCSP responder"查询证书撤销状态。`OCSP.java`：

- `getResponderURI(cert)`（L351-373）：解析证书 **Authority Information Access（AIA）** 扩展中的 `id-ad-ocsp` 项——**URI 完全来自证书内容**（L366-368 取 GeneralName 的 URI）;
- `check`/`getOCSPBytes`（L260-331）：用该 URI 发起 GET（L282-289）或 POST（L290-305）请求，`getInputStream` 读响应（L321-322），finally **`con.disconnect()`**（L326-330）;
- 已强转 `HttpURLConnection`（排除 file:/jar: 等直读协议），带连接/读超时（L285-286）——但**无主机白名单**：URI 指向内网/云元数据也可达;
- 另有 `getOCSPResponse` 入口（L228-243）。

调用场景：`SunCertPathBuilder`/`PKIXRevocationChecker` 校验证书链时，若启用 OCSP（安全属性 `ocsp.enable` 或 RevocationChecker 配置），对每个需要检查的证书按上述逻辑查询。

## 2. 使用方式（如何使用）

- `java.security` 中 `ocsp.enable=true`（或部署启用 CRL/OCSP 策略），所有 TLS 服务端证书/自定义证书链校验自动联 OCSP;
- JDK 内置 `com.sun.net.ssl.internal.www.protocol`、`sun.security.validator` 家族全部走同一实现;
- 校验方也可显式指定 responder（`PKIXRevocationChecker`）——指定路径为应用可控，非本条重点。

## 3. 触发条件分析（什么情况下触发）

**攻击者可控 responder URL 的条件（全部满足）**：

1. 应用的证书路径校验**启用了 OCSP**（默认 `ocsp.enable=false`——生成环境常配 CRL/OCSP 双通道）;
2. 被校验的证书链中有攻击者可控条目：攻击者自建 CA 或受控中间 CA 签发的叶子/中间证书，其 AIA 扩展里 `id-ad-ocsp` 指向任意 URL（如 `http://169.254.169.254/latest/meta-data/`、内网管理端口）;
3. 校验逻辑对该证书条目的 AIA 未做"只允许在证书链内已有 CA"的约束（本实现无此约束——responder 选择纯取 URI）;
4. **注意**：仅当该证书条目的撤销状态确实需要查询（链上证书均需检查、缓存未命中）时发起连接；请求是标准 HTTP GET/POST，带 OCSP 载荷，**响应内容若不满足 OCSP 协议会抛异常使校验失败**——但**请求已经发出**（失败不影响请求已发送的事实），SSRF 通道成立。

**威胁对策现状**：业界对此的既有缓解 = 校验方限制（主流实现会校验 responder 与签发者关系，JDK 未内置）;JDK 提供 `com.sun.security.enableAIAcaIssuers`（默认 false，控制 AIA CA 证书获取，不控制 OCSP host）。

**fd 缓存问题**：`con.disconnect()` 在 finally 恒定执行（L326-330），连接释放正确，与 SRC-4 无交集。

## 4. 威胁场景与影响

- 应用校验攻击者提供的证书链（客户端证书认证、下载源证书校验、SAML 等使用 PKIX 的场景）→ 校验过程中向攻击者指定的内网地址发起 HTTP 请求 → **SSRF / 内网探测 / 云元数据访问**（请求带 OCSP 编码载荷，响应需 OCSP 格式，读取面受限，但请求面完整）;
- 攻击者借此探测内网可达性（响应差异可侧信道判断端口开放）。

## 5. 缓解与修复建议

- 不启用 `ocsp.enable`，改用 CRL（CRL DP 同样有类似面，但通常可配白名单）;
- 需 OCSP 时通过 `PKIXRevocationChecker.setOcspResponder` 显式指定可信 responder（固定主机），并校验返回的 responder 证书;
- 出站防火墙限制 80/443 出向到 CA 白名单主机;
- 若业务校验不可信证书链，考虑禁用 AIA 驱动（`-Dcom.sun.security.enableAIA...` 系仅涉 CA 证书;OCSP host 自定义为主）。

## 6. 审计结论

分级复核：**维持 Medium**。强转 HttpURLConnection + 超时 + disconnect 显示实现质量（非"无防护直读"），缺陷在于**无主机白名单且 URI 来自证书**；触发需要 OCSP 启用 + 攻击者可控证书链条目——半可信配置与外部输入的交界。参考历史（如 CertiVeR/OCSP SSRF 类研究报告），主流处理建议即"固定 responder"。