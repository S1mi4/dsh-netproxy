# 13. [Source/SRC-3] JEditorPane/HTML 渲染 URL 拉取（SSRF/文件读取）— javax.swing

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（文档内 URL → openConnection/getInputStream，无白名单） |
| 严重级别 | Medium（桌面组件，by-design 富文本，渲染不可信内容时触发） |
| 位置 | `java.desktop/javax/swing/JEditorPane.java:640`（charset 重读 `url.openConnection().getInputStream()`）、`:786`（`getStream: page.openConnection()`）、`:804-808`（重定向递归）、`:937`（`new URL(url)` setPage(String)）；同族：`HTMLEditorKit.java:973-1030`、`HTMLDocument.java:3563,4157-4160`、`ImageView.java:199`、`FrameView.java:75,379`、`FormView.java:235,475-480`、`IsindexView.java:108`、`RTFReader.java:702` 等约 30 处 |
| 模块 | java.desktop |

## 1. 在 JDK 中的作用

`JEditorPane` 是 Swing 的富文本展示组件（HTML 3.2/RTF/纯文本），页面加载与子资源拉取由其 `PageLoader`/`getStream` 及 `HTMLEditorKit` 家族完成：

- **页面加载**：`setPage(URL)` → `getStream(URL)`（L785-816）：`page.openConnection()`（L786）→ 应用 postData → 强转 HttpURLConnection 处理重定向（**递归跟随**，L801-808）→ 读流（L816+ 之后）;
- **charset 重定向重读**：read(InputStream) 遇到 `ChangedCharSetException` 且 mark 失效 → `doc` 的 StreamDescription URL → `url.openConnection().getInputStream()`（L640-641）;
- **HTML 子资源**：img/背景/iframe/link/href/表单 action/`<meta refresh>` 等由各 View/Kit 解析文档属性后 `new URL(base, href)` + openConnection（ImageView L199、FrameView L75、HTMLEditorKit L973-1030、HTMLDocument L4157-4160、FormView L235 等）;
- **RTF**：RTFReader 的字体 charset 解析 `href.openStream()`（RTFReader.java:702，与 SRC-2 的 L651 同族）。

## 2. 使用方式（如何使用）

- 应用调用 `editorPane.setPage("http://...")` 或 `setText` + 渲染文档; 
- 邮件客户端、富文本编辑器、帮助浏览器、聊天窗口（HTML 消息）等典型使用者;
- 用户点击链接 → `setPage(String)`（L933-938）→ `new URL(url)` → 拉取。

## 3. 触发条件分析（什么情况下触发）

**风险成立的场景（应用侧决定输入可控性）**：

1. 应用用 JEditorPane/HTMLEditorKit 渲染**不可信 HTML**（外部邮件、用户消息、上传文档）——Swing 没有默认禁网策略，渲染过程中 img/frame/link 全部自动请求;
2. 文档内 `<img src="http://169.254.169.254/latest/meta-data/">`、`<iframe src="http://内网:端口/">`、`<meta http-equiv="refresh" content="0;url=...">` → 渲染即请求 → **SSRF/内网探测**（请求会真实发出，响应被丢弃或报错不影响请求面）;
3. `file:` scheme 同样可达（无协议限制）→ 本地文件内容解析尝试（HTML 解析器会尝试读取——`file:///etc/passwd` 内容进入解析，错误态但已读）;
4. 重定向递归（L801-808）放大跳板（http→http 任意跳转）;
5. 用户点击链接场景：链接 URL 由文档内容与 `getPage` 提供 → 同样直达。

**默认状态**：组件本身不设任何 URL 过滤——安全性 100% 取决于宿主应用是否渲染不可信内容。

**fd 缓存问题**：每次拉取为短连接读流（流用完即关），连接池由 `HttpURLConnection` keep-alive 机制托管；无文件句柄缓存泄漏，与 SRC-4 无交集。

## 4. 威胁场景与影响

- 邮件预览/富文本视图渲染恶意 HTML → 自动向内网/云元数据发请求（SSRF、内网指纹探测、基于请求侧信道的信息泄露）; 
- 结合 `file:` 可尝试读取本地文件内容（解析侧数据受限，但请求面+读面都存在）;
- 表单自动提交（FormView L235 提交 action）进一步放大（可触发内网 POST 面）——不过表单提交需 JS/交互，Swing 无 JS，实际以 GET 面为主。

## 5. 缓解与修复建议

- **不要**用 JEditorPane 渲染不可信内容;如需展示，先做 HTML 清洗（移除 img/iframe/link/meta refresh/form）;
- 子类化 JEditorPane 重写 `getStream(URL)`/`setPage(String)`，对协议+主机做白名单（这是 JDK 提供的官方扩展点，L764-784 javadoc 明示"可重实现以做有用的事"）;
- 设置禁网属性：`HTMLEditorKit` 无内置禁网开关，务必用拦截层。

## 6. 审计结论

分级复核：**维持 Medium（宿主输入决定）**。组件无任何内置防护是其设计（桌面富文本），但"渲染不可信 HTML"是真实高频误用（邮件预览类应用），该场景下实际危害 High。剩余同族命中（HTMLDocument/HTMLEditorKit/ImageView/FrameView/FormView/RTFReader）与本条联动处置：统一在 getStream/URL 解析点加白名单。