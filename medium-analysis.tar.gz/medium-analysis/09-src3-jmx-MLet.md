# 09. [Source/SRC-3] JMX MLet 远程 URL 加载（SSRF + 远程类加载）— MLet / MLetParser

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（URL → openConnection/getInputStream；远程类加载） |
| 严重级别 | Medium（JMX 管理面，by-design 远程加载） |
| 位置 | `java.management/javax/management/loading/MLet.java:412`（`new URL(url)`）；同文件 `:481-509` `getMBeansFromURL(String)`；`MLetParser.java:165`（`conn = url.openConnection()` + L166 `getInputStream()`）、`268`（`new URL(urlname)`） |
| 模块 | java.management |

## 1. 在 JDK 中的作用

`MLet`（**M**-let）是 JMX 规范定义的**远程 MBean 部署服务**：以 URLClassLoader 子类形态存在（`extends URLClassLoader`），允许管理端从任意 HTTP URL 拉取 MLET 描述文件、按其中的 `<MLET CODE=... ARCHIVE=... CODEBASE=...>` 标签从远程 codebase 下载 jar 并实例化 MBean 注册进 MBeanServer。

- `addURL(String)`（L410-422）：把 URL 字符串直接加入类加载路径（无协议/主机校验）;
- `getMBeansFromURL(String url)`（L481-509）：`url` 由调用方指定（**无白名单**）→ `MLetParser.parseURL(url)`（L502）;
- `MLetParser.parseURL`（L251-273）：无 `:` 或 `:` 位置 ≤1 视为相对 user.dir 的本地文件（L255-266），否则 `new URL(urlname)`（L268）;
- `MLetParser.parse(URL)`（L155-246）：**`url.openConnection().getInputStream()`**（L165-166）拉取 MLET 文档；并跟随重定向更新 codebase（L172）;
- 后续（MLet L550-564+）：按 MLET 标签 `CODEBASE`+`ARCHIVE` 拼 `URLClassLoader` 路径下载 jar（`checkJar`/`getJarFile` 走 URLClassPath 的远程 jar 拉取链）。

## 2. 使用方式（如何使用）

- 管理端把 `MLet` MBean 注册到 MBeanServer，再调用 `getMBeansFromURL("http://server/mlets.txt")` 批量部署;
- `MBeanServer.createMBean("javax.management.loading.MLet", ...)` 后远程加载（与报告 03 联动：任意类名 + 远程 jar）;
- J2EE/应用服务器早期时代被广泛用于管理分发。

## 3. 触发条件分析（什么情况下触发）

**SSRF/远程加载成立的场景**：

1. 攻击者能调用 `MLet` 的 `getMBeansFromURL`/`addURL(String)`：
   - JMX 远程端口暴露且认证薄弱/缺省（`-Dcom.sun.management.jmxremote.authenticate=false`）→ 任何 JMX 客户端会话 = 完全控制;
   - 应用内部存在未经授权的 MBeanServer 引用（Spring JMX 导出等）;
2. 传入 URL 指向任意内网地址 → `openConnection().getInputStream()` 发起请求（**SSRF：内网探测、云元数据**）;
3. MLET 文档的 CODEBASE 指向攻击者服务器 → jar 下载 → `Class.forName`-式加载（MLet 的 findClass/loadClass → URLClassLoader）→ **任意远程类 = RCE**;
4. `addURL(String)` 同样无校验：攻击者可逐步注入任意 URL 到 classpath。

**默认状态**：JMX 远程默认关闭 → 默认不可达；一旦开放即全部条件满足。

**fd 缓存问题**：远程 jar 通过 URLClassPath/JarFileFactory 打开并**缓存**（`sun.net.www.protocol.jar.JarFileFactory.fileCache`，带引用计数+close 控制器，见主报告 SRC-4 Info 对照）——这里是"缓存但正确关闭"的设计，不构成 SRC-4；但缓存条目随注入 URL 数量增长，若攻击者不断 addURL 不同 URL 可放大 fd 占用（受 refcount 释放约束，危害有限）。

## 4. 威胁场景与影响

- JMX 攻陷 → SSRF（任意内网请求）+ 任意远程 jar 加载 → RCE; 
- 历史案例：各类 JMX 未授权访问导致 MLet 投递 RCE（CVE-2016-8735 家族）;
- 即使无远程类，MLet 的 URL 拉取本身就是稳定的盲 SSRF 通道。

## 5. 缓解与修复建议

- 生产禁止开放 JMX 远程或仅 loopback+TLS+强认证; 
- 不注册 MLet MBean（或注册自定义受限子类：校验 URL 协议/主机白名单、禁用 getMBeansFromURL）;
- MBeanServer 级拦截器过滤 `getMBeansFromURL`/`addURL` 参数。

## 6. 审计结论

分级复核：**维持 Medium（条件触发型）**。by-design 的远程服务特性，安全边界=JMX 访问控制；边界失守时本条为 SSRF+RCE 双重 High。与报告 03（MBeanInstantiator）构成 JMX 暴露链的"类名+货源"两端。