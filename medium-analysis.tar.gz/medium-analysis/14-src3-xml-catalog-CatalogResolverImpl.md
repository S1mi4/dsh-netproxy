# 14. [Source/SRC-3] XML Catalog 解析 SSRF — CatalogResolverImpl

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（URL → openStream，无白名单） |
| 严重级别 | Medium（catalog 内容为半可信配置；文档不可信时按文档 URI 解析） |
| 位置 | `java.xml/javax/xml/catalog/CatalogResolverImpl.java:222`（`new URL(is.getSystemId()).openStream()`）；同族 `BaseEntry.java:226-228`（`new URL(base, uri)`，仅创建不联网）、`CatalogImpl.java:145`（`baseURI = new URL(systemId)` 仅创建） |
| 模块 | java.xml（OASIS XML Catalog，JAXP 1.5+） |

## 1. 在 JDK 中的作用

`CatalogResolverImpl` 把 JAXP 解析器与 OASIS XML Catalog 集成：当 SAX/DOM/StAX 解析器遇到需要解析的 systemId/publicId 时，用它替换默认的 EntityResolver/URIResolver：

- `resolveEntity(publicId, systemId)`（L216-240）：先在 catalog 中查映射 → 映射命中返回 `InputSource`（systemId=catalog 条目值）→ **`new URL(is.getSystemId()).openStream()`**（L222）直接把 catalog 指向的资源拉成 InputStream 喂给解析器;
- `resolve(String href, String base)`（L135-177）：无映射时 `new URL(uri)`/`new URL(baseURL, uri)` 只构造 URL 并返回 SAXSource（L156-166——**仅创建，不联网**）;
- 配合 `CatalogImpl.loadCatalog` → `GroupEntry.verifyCatalogFile`（见报告 16）加载 catalog 文件本身。

## 2. 使用方式（如何使用）

- 应用配置 catalog：`factory.setFeature(USE_CATALOG, true)` + `setAttribute(CATALOG, "catalog.xml")`（或系统属性/SPI 发现）;
- 解析 XML/DTD/XSLT 时自动走 catalog 映射，用于离线约束解析、内部资源重定向等;
- catalog 文件可含 `nextCatalog` 链式引用、`uri`/`system`/`public`/`rewriteURI` 等条目。

## 3. 触发条件分析（什么情况下触发）

**L222 的 openStream 达成条件**：

1. EntityResolver 命中了 catalog 映射（`Util.resolve` 返回非空）——systemId 为 **catalog 条目值**（catalog 文件内容决定）;
2. 或 catalog 未映射但 `resolveEntity` 返回非空 InputSource 的其他路径;
3. **触发方可控性分析**：
   - **catalog 文件内容**：管理员配置（可信）→ 一般只影响"配置被投毒"场景（Medium）;
   - **被解析文档**：catalog 的 system 条目匹配是按键查找，文档中的 systemId 不会原样进 L222（除非 catalog 有通配/rewrite 到不可信位置并同配了开放 resolver）——但 **rewriteURI/systemSuffix 类条目 + 不可信文档**组合下，映射结果可由文档驱动（如 `systemSuffix` 把任意后缀映射到固定前缀 URL）——此时文档间接控制最终 URL（Medium 场景成立）;
4. URL 无协议/主机白名单：`file:`、`http:`、内网地址均可。

**默认状态**：catalog 功能默认**关闭**（USE_CATALOG 默认 false）→ 默认不触发。

**fd 缓存问题**：流由解析器消费后关闭（EntityResolver 返回的 InputStream 由 SAX 解析器负责 close），无缓存泄漏；本文件的 JarFile 泄漏点在 Util.java（见报告 16）。

## 4. 威胁场景与影响

- catalog 文件被篡改（部署目录可写、配置注入）→ 解析任何 XML 时向攻击者指定地址拉取内容（SSRF + 内容注入到解析上下文）;
- 不可信文档 + 开放 catalog 规则 → 请求面可达内网/云元数据;
- 由于被拉内容会进入解析器进一步解析，可能叠加 XXE/毒化（范围外）。

## 5. 缓解与修复建议

- 默认不启用 USE_CATALOG；启用时 catalog 文件必须以受信路径部署 + 权限收紧;
- catalog 规则只使用 `uri` 精确映射，避免 `systemSuffix`/`rewrite*` 通配到外部;
- 需要时在 entityResolver/URIResolver 外层做协议+主机白名单。

## 6. 审计结论

分级复核：**维持 Medium**。与报告 08 同族（XML 处理链的"按需拉取"），但默认关闭 + 主要输入为管理员 catalog 配置；高危化前提=配置投毒或通配规则+不可信文档。BaseEntry/CatalogImpl 的 `new URL` 仅构造对象不联网，维持 Info 不升级。