# Medium 条目深入分析 —— 索引与总览

> 本目录为 `jdk-src/source-sink-report.md` 中 **17 条 Medium 级发现**的独立深入分析。
> 每条报告独立成文，均包含：在 JDK 中的作用（模块/职责）、使用方式（调用链/典型宿主）、
> 触发条件（含默认状态源码级核实）、威胁场景与影响、修复/缓解建议、分级复核结论。
> 源码版本：OpenJDK 17.0.19（Ubuntu 26.04，`openjdk-17-source`），行号以该版本 grep 为准。

## 逐条索引

| # | 文件 | 规则 | 核心结论（触发条件一句话） |
|---|------|------|----------------------------|
| 01 | [snk1-ObjectInputStream-resolveClass](01-snk1-ObjectInputStream-resolveClass.md) | SNK-1 | 反序列化类名可控的基础原语；无 ObjectInputFilter 时任意反序列化即触发 |
| 02 | [snk1-jndi-ldap-VersionHelper-loadClass](02-snk1-jndi-ldap-VersionHelper-loadClass.md) | SNK-1 | LDAP 属性类名 + `initialize=true`；`trustURLCodebase/trustSerialData` **默认 false** 门控 |
| 03 | [snk1-jmx-MBeanInstantiator](03-snk1-jmx-MBeanInstantiator.md) | SNK-1 | JMX createMBean 任意类实例化；JMX 暴露/弱认证即触发 |
| 04 | [snk1-rowset-SyncFactory](04-snk1-rowset-SyncFactory.md) | SNK-1 | providerID 来自配置文件/调用方；`rowset.properties` 投毒或透传输入时触发 |
| 05 | [snk2-rowset-JdbcRowSetImpl](05-snk2-rowset-JdbcRowSetImpl.md) | SNK-2 | Rowset URL 属性→getConnection；反序列化 gadget 经典链 |
| 06 | [snk2-rowset-CachedRowSetReader](06-snk2-rowset-CachedRowSetReader.md) | SNK-2 | 同 05，覆盖面为全部 com.sun.rowset 缓存家族（含 WebRowSet XML 面） |
| 07 | [src3-xmldsig-ResolverDirectHTTP](07-src3-xmldsig-ResolverDirectHTTP.md) | SRC-3 | 验证不可信签名 XML 时 Reference URI 直达 HTTP 拉取；**请求先于签名校验**，默认 scheme 不设限 |
| 08 | [src3-jaxp-XMLEntityManager](08-src3-jaxp-XMLEntityManager.md) | SRC-3 | 外部实体/DTO 拉取；**默认 FSP=true→accessExternalDTD="" 拒绝**，显式放行后才触发 |
| 09 | [src3-jmx-MLet](09-src3-jmx-MLet.md) | SRC-3 | MLet MBean 可达时任意 URL 拉取 + 远程 jar 类加载 |
| 10 | [src3-jndi-ldap-javaCodebase](10-src3-jndi-ldap-javaCodebase.md) | SRC-3 | LDAP javaCodebase→URLClassLoader；`trustURLCodebase=false` 默认阻断 |
| 11 | [src3-rmi-codebase-LoaderHandler](11-src3-rmi-codebase-LoaderHandler.md) | SRC-3 | RMI 流注解 codebase 远程加载；`useCodebaseOnly=true` 默认阻断 |
| 12 | [src3-pkix-OCSP](12-src3-pkix-OCSP.md) | SRC-3 | 证书 AIA 的 OCSP URL 无主机白名单；ocsp.enable + 攻击者证书链时触发 |
| 13 | [src3-swing-JEditorPane](13-src3-swing-JEditorPane.md) | SRC-3 | 渲染不可信 HTML → 文档内 URL 自动拉取（含重定向递归、file:） |
| 14 | [src3-xml-catalog-CatalogResolverImpl](14-src3-xml-catalog-CatalogResolverImpl.md) | SRC-3 | catalog 映射命中→openStream；USE_CATALOG 默认关，配置投毒/通配规则时触发 |
| 15 | [src4-xsltc-TransformerFactoryImpl](15-src4-xsltc-TransformerFactoryImpl.md) | SRC-4 | auto-translet+jar-name 时每次 newTemplates 泄漏 1 个 ZipFile fd（**真实可达缺陷**，无关闭路径） |
| 16 | [src4-catalog-Util-jarfile](16-src4-catalog-Util-jarfile.md) | SRC-4 | Util L197 JarFile 无关闭；**本版本 openJarFile=true 无调用方→潜在缺陷**（不可达） |
| 17 | [src4-jdeprscan-ClassFinder](17-src4-jdeprscan-ClassFinder.md) | SRC-4 | jar 句柄缓存至进程退出；CLI 短生命周期→低实际影响 |

## 汇总要点

- **门控型攻击面（02/08/10/11）**：默认开关即防线——`trustURLCodebase`、`trustSerialData`、`FEATURE_SECURE_PROCESSING/ACCESS_EXTERNAL_DTD`、`useCodebaseOnly` 全部**默认安全**;审计/加固重点是确认宿主未显式关闭。
- **无条件攻击面（01/03/05/06/07/09/12/13/14）**：防护完全依赖宿主调用方式（反序列化过滤器、JMX 认证、渲染不可信内容与否、XML 签名来源信任）——这些是"宿主应用交付安全"的责任点。
- **真实资源缺陷（15）**：XSLTC `getBytecodesFromJar` 无关闭路径，可达、可量化（每 newTemplates +1 fd）——优先修复项。
- **潜在/低影响（16/17）**：缺陷客观存在但触发缺失或影响有限，如实标注。
- **fd 缓存语义澄清**：SRC-4 类问题中"缓存"分两类——① 设计性缓存（URLClassPath/JarFileFactory/ZipFile.Source：**引用计数+关闭路径完整**，属 Info 安全对照）;② 缺陷性缓存/裸开（15/16/17：无关闭路径）。17 条 Medium 中仅 15/16/17 涉及 fd，其余条目与 fd 缓存无关联（已逐条注明）。

## 修复优先级建议

1. **P0（应用侧）**：反序列化过滤器（01/05/06）、JMX 访问控制（03/09）、XSLTC jar 模式替换或降级（15）;
2. **P1（配置加固）**：trust* =false 固化（02/10）、useCodebaseOnly 固化（11）、XML 安全属性（07/08）、OCSP responder 固定（12）、关闭 USE_CATALOG 或收紧 catalog 部署（14/16）;
3. **P2（代码级）**：15/16/17 三处 JDK 上游修复（try-with-resources）;
4. **P3（组件使用规范）**：JEditorPane 渲染白名单（13）、SyncFactory providerID 校验（04）。