# 17. [Source/SRC-4] jdeprscan JarFile 缓存不关闭 — ClassFinder.JarPathEntry

| 项目 | 内容 |
|------|------|
| 规则 | SRC-4（JarFile 缓存无关闭路径） |
| 严重级别 | Medium（实际影响低：CLI 工具进程短生命周期） |
| 位置 | `jdk.jdeps/com/sun/tools/jdeprscan/scan/ClassFinder.java:77`（`list.add(new JarPathEntry(new JarFile(jarName)))`），内部类 `JarPathEntry`（L122-144，`final JarFile jarFile` 字段） |
| 模块 | jdk.jdeps（jdeprscan 命令行工具） |

## 1. 在 JDK 中的作用

`ClassFinder` 是 **jdeprscan 工具**的类路径扫描器：给定目录/jar/jrt 集，按类名查找 `.class` 字节码以分析废弃 API 使用。结构：

- `ClassFinder` 持有 `List<PathEntry> list`（L50），`addDir`/`addJar`/`addJrt`（L62-86）向列表追加条目;
- `addJar(jarName)`（L75-79）：**`new JarFile(jarName)` 直接存入 `JarPathEntry.jarFile` 字段**——IOException 时吞掉（L78）;
- `JarPathEntry.find(className)`（L130-143）：`jarFile.getJarEntry(...)` → `jarFile.getInputStream(entry)` → `ClassFile.read` 读取（L136）;
- **全类核实（L1-211 通读）**：`JarPathEntry` 未实现 `AutoCloseable`，`ClassFinder` 无 close()，`Main`/`Scan` 亦无关闭调用——**jar 句柄持有至进程退出**。

入口：`jdeprscan [--class-path ...] [dirs/jars]`（`Main.java` 构建 ClassFinder → `Scan` 逐类 `find`）。

## 2. 使用方式（如何使用）

- 命令行：`jdeprscan --class-path lib/a.jar:lib/b.jar com.example.App`，或直接 `jdeprscan lib/a.jar lib/b.jar`——工具把参数中每个 jar 打开并放入查找表，然后扫描类;
- 典型用量：构建流水线 CI 步骤扫描一批依赖 jar;一个进程扫 N 个 jar = 同时持有 N 个 JarFile fd;
- `ClassFinder` 是 `com.sun.tools.jdeprscan` 包内类型（非公共 API），不会被正式嵌入使用（不退避原则：开发者工具包）。

## 3. 触发条件分析（什么情况下触发 fd 缓存/打开而不关闭）

**确切条件与量化**：

1. 运行 jdeprscan，命令行给出 ≥1 个 jar → `addJar` 每个 jar 打开一个 JarFile 存入列表——**所有 jar 句柄一次性缓存**（L77）;
2. 扫描期间所有 jar 保持打开（`find` 反复 `getJarEntry`/`getInputStream`）——这是设计的"缓存"（避免反复重开）;
3. 关闭缺失：进程退出前无 close——**句柄存活 = 进程存活**（JVM 退出时 OS 回收，无实际泄漏窗口）;
4. 放大前提：该工具有 `-e`（递归遍历）与并发?（无）——单进程 fd 峰值 = 参数 jar 数 + JRT 文件系统;
5. **若**将其嵌入长驻进程（反模式，非公开 API）→ N 次扫描累积 N×jar 数 fd → 泄漏;当前无此用法。

**结论**：CLI 批处理工具，进程退出即全部释放——**实际影响最小**;规则判定（缓存不关闭+长期运行累积）成立，但"长期运行"前提在本工具不成立。

## 4. 威胁场景与影响

- 常规使用：单次进程，fd 峰值为参数规模（数百 jar ≈ 数百 fd，通常低于 ulimit），退出即释放——无 DoS;
- 防御性考量：若 CI 在长驻代理进程内反复调用（极少见），fd 累积可致服务 DoS——属工具嵌入误用;
- 与 JDK 正确写法对照：`jdeprscan` 同包的 `Scan.java:600`（`try (JarFile jf = new JarFile(jarname))`）正确关闭——本处是不一致遗漏。

## 5. 缓解与修复建议

- **修复**：`JarPathEntry` 实现 `AutoCloseable`，`ClassFinder` 增加 `close()` 遍历关闭，`Main` 扫描结束调用（try-with-resources）;
- 宿主侧：无动作必要（CLI 工具）;如确有嵌入需求，自行反射/复制实现并管理关闭。

## 6. 审计结论

分级复核：**维持 Medium（低实际影响）**。规则层面"缓存不关闭"成立（符合 SRC-4 Medium 判据），工具形态（命令行、进程短命）大幅压低危害;如实标注，避免过度夸大。修复本身成本低，可在 JDK 上游提交。