# 07. [Source/SRC-3] XML 签名参考解析 SSRF — ResolverDirectHTTP

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（URL → openConnection/getInputStream，SSRF 入口） |
| 严重级别 | Medium（处理不可信签名文档时可按默认配置触发） |
| 位置 | `java.xml.crypto/com/sun/org/apache/xml/internal/security/utils/resolver/implementations/ResolverDirectHTTP.java:115-116,187,196`（`uriNew.toURL()` → `url.openConnection()`/`(proxy)` → L142 `getInputStream()`）；上游链 `org/jcp/xml/dsig/internal/dom/DOMURIDereferencer.java:148-150` |
| 模块 | java.xml.crypto |

## 1. 在 JDK 中的作用

XML 数字签名（XMLDSig，JSR 105 实现）允许 `<Reference URI="...">` 引用**外部资源**作为待签名数据。`ResolverDirectHTTP` 是 Santuario 资源解析器对 http/https 协议的实现：验证签名时若 Reference 指向外部 URI，就由它发起 HTTP 请求取回数据。调用链：

`XMLSignature.validate()` → `DOMReference.dereference()` → `DOMURIDereferencer.dereference()`（org.jcp 层，JDK 的默认 URIDereferencer）→ 非文档内引用（URI 不以 `#` 开头）落入 L148-150 → `ResourceResolver.resolve(context)` → 注册的 resolver 列表 → `ResolverDirectHTTP.engineCanResolveURI`（http/https 命中）→ `engineResolveURI`（L109-166）→ `getNewURI(uriToResolve, baseUri).toURL()` → `openConnection(url)` → `getInputStream()` 读回字节。

## 2. 使用方式（如何使用）

- 应用标准用法：`XMLSignatureFactory` + `DOMValidateContext` 验证 SAML 断言、代码签名清单（JAR 签名 XML）、SOAP WS-Security 签名等;
- Reference URI 由被验证的 XML 文档**自身**携带——这是协议设计（`<ds:Reference URI="http://server/doc.xml">`）;
- 管理员可通过 `jdk.xml.dsig.secureValidationPolicy` 安全属性配置禁用某类 scheme / 限制算法（`Policy` 类，L65-140：`disallowReferenceUriSchemes` 等）。

## 3. 触发条件分析（什么情况下触发）

**SSRF 触发路径（已验证默认状态）**：

1. 应用验证**攻击者可控的 XML 签名文档**（SAML 响应、上传的签名文件、SOAP 消息）——这是触发前提，应用侧信任边界;
2. 文档的 `<Reference URI="http://169.254.169.254/latest/meta-data/…">` 或任意内网地址 → 不以 `#` 开头 → 走外部解析;
3. 默认配置核实：
   - `Utils.secureValidation(context)` 默认 **true**（`DOMValidateContext` 构造时 `setProperty("org.jcp.xml.dsig.secureValidation", Boolean.TRUE)`，见 `DOMValidateContext.java:114`）;
   - 但 `Policy.restrictReferenceUriScheme` 的 `disallowedRefUriSchemes` 集合**默认空**（`Policy.java:71,80-82`：未配置 `jdk.xml.dsig.secureValidationPolicy` 时"不施加任何限制"）——**http/https 参考默认放行**;
   - `ResolverDirectHTTP.engineResolveURI` 自身不检查 secureValidation（L109-166 无门控，仅 L155 把标志传给结果对象）;
4. **关键时序**：dereference 发生在签名**验证成功之前**——即使攻击者不知道签名私钥（签名必然校验失败），**外部 URI 的 HTTP 请求已在验证过程中发出**，SSRF 恒定触发，不存在"签名无效就不请求"的天然防线。

**fd 缓存问题**：本条无文件句柄缓存。连接为短生命周期读流，`HttpURLConnection` 读尽即释放（keep-alive 由连接池托管），无 SRC-4 相关性。

## 4. 威胁场景与影响

- 内网探测/云元数据窃取（169.254.169.254）、对任意内网服务发起 GET 请求（配合参数型端点打"签名验证驱动的盲请求"）;
- 历史上 Santuario 同类问题为 CVE-2013-2179（外部参考解析被滥用），JDK 的缓解=安全属性显式配置，而非默认阻断。

## 5. 缓解与修复建议

- 在 `java.security` 配置：`jdk.xml.dsig.secureValidationPolicy=disallowReferenceUriSchemes http https ftp jar`（按需收紧）;
- 验证不可信文档前，自定义 `URIDereferencer`（`XMLValidateContext.setURIDereferencer`）做**协议+主机白名单**并在白名单外抛异常——这是唯一可靠的组件级缓解;
- 业务侧：SAML/签名文档来源限定可信 IdP。

## 6. 审计结论

分级复核：**维持 Medium，触发场景下等价 High**。工具面无缺陷（resolver 只是忠实执行协议），但默认配置下没有任何 scheme 限制，且请求先于签名校验——任何"验证不可信 XML 签名"的应用都处于 SSRF 暴露。强烈建议按第 5 节配置安全属性 + 自定义 URIDereferencer。

---

## 7. 实测验证补充（2026-08-26 · JDK 17.0.19 本机实证）

### 7.1 验证环境与物料

- 应用侧：JavaResearch 项目新增 `/xml` 接口（`XmlController.java`），POST 参数 `xml`（签名文档）+ `baseUri` + `pubKey`，内部 `DOMValidateContext` + `unmarshalXMLSignature` + `validate`；
- 触发文档：`XmlSigGen.java` 生成的**合法自签名** XMLDSig（RSA-2048 + rsa-sha256，`<ds:Reference URI="jar:http://127.0.0.1:2333/test!/test.pem">`，DigestMethod SHA-256，摘要对真实拉取的 jar 内容计算）；
- 目标服务器：`127.0.0.1:2333` keep-alive HTTP 测试服务器（`server.py`），对 `GET /test` 返回含 `test.pem` 条目的合法 jar（505 B）并保持连接不关闭。

### 7.2 实测触发链路（全部源码级确认）

```
POST /xml → unmarshalXMLSignature(vc) → signature.validate(vc)
 ① DOMSignatureValue.validate：验签（KeySelector 取公钥）   [DOMXMLSignature.java:284]
 ② if (!sigValidity) return;                                [287-289 ← 关键闸门]
 ③ References 循环 → ref.validate → dereference             [295]
 ④ DOMURIDereferencer.dereference → ResourceResolver.resolve [DOMURIDereferencer.java:148]
 ⑤ ResolverDirectHTTP.engineCanResolveURI：jar: 前缀不匹配
    http:/https:；baseUri 为 http(s) 前缀 → 放行            [ResolverDirectHTTP.java:222]
 ⑥ engineResolveURI → getNewURI().toURL() → openConnection()
    → sun.net.www.protocol.jar.Handler/JarURLConnection
    → GET http://127.0.0.1:2333/test                          [ResolverDirectHTTP.java:114-116,142]
```

实测结果：`valid=true`，应用进程向 2333 发出 `GET /test`，读取 jar 并算出匹配摘要。

### 7.3 关键闸门 ①：验签必须先通过（对条目 3.4"时序"论述的重要修正）

条目 3.4 称"dereference 发生在签名验证成功**之前**——签名必然校验失败时外部 URI 请求也会发出"。**实测与 JDK 17.0.19 源码不符**：

- `DOMXMLSignature.validate` 先执行 `sv.validate(vc)`，**返回 false 时提前 return**（[DOMXMLSignature.java:287-289]），References 循环（含 dereference）**根本不会执行**；
- 使用占位假签名（4 字节 `SignatureValue`）的文档在验签阶段直接抛 `SignatureException: Bad signature length`（RSA-2048 期望 256 字节），2333 服务器**零请求**；
- 换成合法自签文档（攻击者自持密钥签名，无需任何私钥泄露）后立即触发。

→ **修正**：外部 URI dereference 以签名值验证通过为前提。攻击者用自持密钥自签即可满足；若应用侧 KeySelector 可控或验证结果不受检，则更直接。缓解不能依赖"签名校验拦截"，仍需 5 节的 resolver 白名单/安全属性。

### 7.4 关键闸门 ②：baseUri 与 jar: 的关联（四组对照实验）

以配对密钥的合法签名文档验证（`XmldsigProbe`，args = `xml baseUri pubKey`）：

| baseUri | validate | 2333 请求 | 结论 |
|---|---|---|---|
| `http://127.0.0.1:2333/`（回归基线） | true | ✅ GET /test | 触发成立 |
| `http://9.9.9.9/`（http 前缀、主机无关） | true | ✅ 请求仍打 `127.0.0.1:2333` | **baseUri 只做放行、不参与 URL 构造**（`getNewURI` 对绝对 jar: URI resolve 自返，[ResolverDirectHTTP.java:234-246]） |
| `file:///tmp/x`（非 http 前缀） | false | ❌ 零请求 | **不是"有值就行"**，必须 `http:`/`https:` 开头（[ResolverDirectHTTP.java:222] 条件三） |
| `null`（不设置，JDK 默认） | false | ❌ 零请求 | baseURI 默认 null；未设置则 jar: 不被认领 |

→ 关联结论：**baseURI 与 Reference 的 jar URL 无内容拼接关系，其唯一作用是 engineCanResolveURI 对"非 http/https 前缀 URI"（如 jar:）的放行条件**；触发的先决条件是"非 null 且 `http:`/`https:` 开头"。

### 7.5 fd 缓存实证（与 SRC-4 的衔接）

单次 `/xml` 验证产生两条 `GET /test`（服务器日志 [7][8]），生命周期完全不同：

- **内层连接（fd 悬挂主载体）**：`engineResolveURI` 先调 `getHeaderField("WWW-Authenticate")`（[ResolverDirectHTTP.java:117]）→ JarURLConnection 的内层 http 连接发出 GET 但**响应体从未被读取/关闭** → 连接滞留 `ESTABLISHED`、fd 悬挂——实测 `java fd=14` 跨两次请求、40 秒以上保持不释放，且**每次新请求都会新增一条**；
- **下载连接（短暂）**：`connect()` → `URLJarFile.retrieve`（try-with-resources 读尽 jar 字节并落盘临时文件 `jar_cache*`）→ 连接归还 keep-alive 池，空闲数秒后被回收（服务器观测到 EOF）；
- **跨请求缓存**：JarFile 被 `JarFileFactory` 强缓存（key=`http://127.0.0.1:2333/test`），第二次同 URI 验证仅 3ms 完成、仅发内层 GET（无重新下载）——缓存命中复用，fd 按请求数累积悬挂。

### 7.6 踩坑记录（供复测者参考）

1. **假签名零请求**：验签失败（false 或异常）→ references 不执行。凡以"签名无效也应触发"为前提的实验设计都会得到假阴性（本轮前三组实验即因此全部归零）；
2. **密钥文件被生成器覆盖**：`XmlSigGen` 每次运行都生成新密钥对，若密钥文件与签名文档分属不同次运行，公钥-签名不匹配 → 验签失败提前短路，实验组间必须确保密钥配对（已改为密钥文件随输出名生成：`sign2-pub.b64` 等）；
3. `/xml` 接口层"baseUri 缺省默认 `http://127.0.0.1:2333/`"仅为演示便利，**不是 JDK 默认行为**（JDK 默认 null，见 7.4）。

### 7.7 审计结论更新

- 分级维持条目原文：**Medium（触发场景下等价 High）**；
- jar: 变体的触发依赖收敛为：**验签通过（攻击者自签可满足）+ baseUri 为 http(s) 前缀（应用侧常见配置）+ Policy 默认不拦 jar scheme**；
- 修正点：外部引用请求**不先于**签名校验（见 7.3），条目 3.4 的时序论述应以本节为准；
- 缓解建议不变：`jdk.xml.dsig.secureValidationPolicy=disallowReferenceUriSchemes http https ftp jar` + 自定义 `URIDereferencer` 做协议/主机白名单（条目 5 节）。

### 7.8 复测命令

```bash
# 生成合法自签触发文档（输出 sign2.xml + sign2-pub.b64）
java XmlSigGen "jar:http://127.0.0.1:2333/test!/test.pem" sign2.xml

# 独立探针验证（XmldsigProbe：xml baseUri pubKey；baseUri 传 null 表示不设置）
java XmldsigProbe sign2.xml "http://127.0.0.1:2333/" "$(cat sign2-pub.b64)"

# 或经应用 /xml 接口
curl -X POST http://127.0.0.1:8080/xml   --data-urlencode "xml@sign2.xml"   --data-urlencode "baseUri=http://127.0.0.1:2333/"   --data-urlencode "pubKey=$(cat sign2-pub.b64)"

# 观测：server.log 出现 "REQUEST: GET /test"；ss -tnp | grep 2333 可见 ESTABLISHED 悬挂连接
```

验证辅助代码与产物位于仓库外同机目录 `~/workspace/jndi-lab/`（`XmlSigGen.java`、`XmldsigProbe.java`、`sign2.xml`、`server.py`、application `/xml` 接口 `XmlController.java`）。
