# 01. [Sink/SNK-1] Class.forName — ObjectInputStream.resolveClass

| 项目 | 内容 |
|------|------|
| 规则 | SNK-1（Class.forName 反射加载） |
| 严重级别 | Medium（反序列化核心原语，by-design） |
| 位置 | `java.base/java/io/ObjectInputStream.java:773`（同族：`java.base/java/io/ObjectInputStream.java:846` resolveProxyClass、`desc.getName()` 流侧类名） |
| 模块 | java.base |

## 1. 在 JDK 中的作用

`ObjectInputStream` 是 Java 对象序列化机制的**反序列化端核心**。`resolveClass(ObjectStreamClass desc)` 是它把流中类描述符解析为 `Class` 对象的钩子：每从流中读到一个对象，都会先用本方法确定该对象的实际类型，然后才能构造实例、填充字段。

- L773 `Class.forName(name, false, latestUserDefinedLoader())`：类名直接取自流中 `ObjectStreamClass` 描述符（`desc.getName()`）；`latestUserDefinedLoader()` 取调用栈上第一个非平台类加载器（即"发起反序列化的应用"的类加载器）；
- L836-869 `resolveProxyClass(String[] interfaces)`：动态代理类描述符的接口名同样来自流数据（L846 `Class.forName(interfaces[i], false, latestLoader)`）；
- 该机制对**整个 JDK 及所有应用**生效：RMI 传输、JNDI/LDAP 序列化对象、JMX 传输、Session/缓存序列化，最终都落在这两个方法上。

## 2. 使用方式（如何使用）

不可直接"调用"，它是平台反序列化管线的一部分，任何代码执行 `new ObjectInputStream(...).readObject()` 都会经过它。JDK 内部的典型使用者：

- RMI：`sun.rmi.server.MarshalInputStream`（子类化 OIS，先按 codebase 注解解析，失败后回落 `super.resolveClass` → 本条）;
- JNDI LDAP：`com.sun.jndi.ldap.Obj.deserializeObject`（见报告 02/10）;
- JMX：`ObjectInputStreamWithLoader`、`MBeanInstantiator` 反序列化参数;
- 应用侧：HttpSession、MQ、缓存框架、消息队列的任何反序列化。

## 3. 触发条件分析（什么情况下触发）

**触发条件（全部满足才构成攻击面）**：

1. 应用中存在 `ObjectInputStream.readObject()` 入口，且流的来源可被攻击者控制（HTTP body、MQ 消息、RMI 远程流、LDAP 属性、上传文件等）——这是应用侧责任；
2. 该 OIS **未设置过滤器**：JDK 17 默认**不启用**全局 `ObjectInputFilter`（`jdk.serialFilter` 默认为空），`ObjectInputStream` 的 `serialFilter` 字段默认 null（仅当宿主显式 `setObjectInputFilter` 或配置 `jdk.serialFilter` 系统属性/安全属性才生效，见同一文件 L1334 与 `jdk.internal.util.xml` 无关，过滤器 API 为 `java.io.ObjectInputFilter`）;
3. 攻击者 classpath 中存在可用 gadget 类（如第三方库常见组件），或把恶意类文件放入可加载路径（配合 SNK-1 任意类加载的"静态初始化即执行"特性：`Class.forName(name, false, loader)` 本身 `initialize=false`，但对象构造/`readResolve`/`readObject` 回调会执行任意代码）。

**特别注意**：`Class.forName` 的 `false`（不初始化）只推迟 static 块，但反序列化随后必然实例化该 class，因此 gadget 链照常生效——`false` 标志不能作为安全辩解。

**fd 缓存问题**：本条与文件句柄缓存无直接关系（不涉及 RandomAccessFile/ZipFile）；若反序列化链路中存在读取本地文件的 gadget，fd 生命周期由对应 gadget 自行管理。

## 4. 威胁场景与影响

- 应用反序列化不可信数据（无过滤器）→ 类名可控 → 加载/实例化任意类 → RCE；这是 2015 年以来所有 Java 反序列化漏洞（RMI/JMX/JBoss/WebLogic 等）的公共根因；
- 与报告 02/05 联动：JNDI LDAP 的 `javaSerializedData` 与 RowSet 反序列化链最终都通过本方法解析类。

## 5. 缓解与修复建议

- **必须**在反序列化入口配置 `ObjectInputFilter`（`-Djdk.serialFilter` 全局或 `setObjectInputFilter` 局部），白名单放行业务类；
- 不要对不可信数据使用原生 `readObject()`；优先 `readObject(filter)`；
- 升级依赖消灭已知 gadget；JEP 415 之后 JDK 17 提供 `ObjectInputFilter.Config.createFilter`。

## 6. 审计结论

分级复核：**维持 Medium**。本条是 JDK 设计核心而非缺陷，但它是 JDK 内所有反射加载链的汇聚点；在"应用无过滤器反序列化不可信数据"这一真实场景下实际危害为 High。报告依 skill 规则将其列为 Medium（by-design 原语），并强制提示过滤器配置必要性。