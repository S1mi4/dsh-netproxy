# 11. [Source/SRC-3] RMI codebase 远程类加载（SSRF/远程类）— LoaderHandler

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（codebase URL → 远程类加载；L1049 openConnection 权限推导） |
| 严重级别 | Medium（受 useCodebaseOnly 默认 true 保护） |
| 位置 | `java.rmi/sun/rmi/server/LoaderHandler.java:776`（`new URL(st.nextToken())` pathToURLs）、`1049`（`url.openConnection().getPermission()`）、`1106`（`hostURL.openConnection()`）；联动 `sun/rmi/server/MarshalInputStream.java:66-69,187-196,236-238` |
| 模块 | java.rmi |

## 1. 在 JDK 中的作用

RMI 协议的类解析支持"代码库注解"：序列化流中每个类描述符可携带一个 `java.rmi.server.codebase` URL 列表（目标端据此下载缺失类）。`LoaderHandler` 承担三件事：

- `pathToURLs(path)`（L764-783）：把空格分隔的 codebase 字符串解析为 `URL[]`（L776 `new URL(st.nextToken())`，结果缓存于 WeakHashMap L785-787）;
- `getClassLoader(codebase)` / `loadClass(codebase, name, loader)`（L156-189）：构造/复用基于 URL 的类加载链;
- `addPermissionsForURLs`（L1042-1114）：为来自 codebase 的类计算权限——L1049 `url.openConnection()` **只调 `getPermission()`（不读数据、不建连）**，L1106 同类（jar: 内层 URL 的权限推导）。

数据流入口：`MarshalInputStream.resolveClass`/`resolveProxyClass`（L180-242）——RMI 服务端/客户端反序列化对端流时读取位置注解：**仅当 `!useCodebaseOnly` 且注解为 String** 才把注解值作为 codebase（L193-196），否则 codebase=null（回落本地 `java.rmi.server.codebase` 属性）。

## 2. 使用方式（如何使用）

- 分布式应用：客户端/服务端把 stub、接口实现类放在 HTTP 服务器，远程 JVM 配置 `-Djava.rmi.server.codebase=http://server/classes/`，对端缺类时自动下载;
- `RMIClassLoader` 公共 API（java.rmi.server.RMIClassLoader）封装上述逻辑，供自定义传输层使用。

## 3. 触发条件分析（什么情况下触发）

**远程拉取成立的条件（默认门控核实）**：

1. `java.rmi.server.useCodebaseOnly` **默认 "true"**（`MarshalInputStream.java:66-69` 静态初始化实测）→ 流注解 codebase 被忽略，只允许本机属性 codebase → **默认阻断攻击者注解**;
2. 要触发远程加载必须显式 `-Djava.rmi.server.useCodebaseOnly=false`，且：
3. 处理**不可信对端**的 RMI 流（RMI 服务暴露给外部、或反序列化 RMI 载荷）;
4. 注解 URL 指向攻击者 HTTP 服务器（或内网地址）→ URLClassLoader 按需 `openConnection().getInputStream()` 拉取。
5. JDK 17 无 SecurityManager：`LoaderHandler` 内围绕 `SecurityManager`/`RMISecurityManager` 的权限检查（L308-313 `checkPermission(new RuntimePermission("getClassLoader"))` 等）全部失效——**安全性完全依赖 useCodebaseOnly 开关**。

**L1049/L1106 本身**：只做 `getPermission()`（FilePermission/SocketPermission 推导，不联网）——不是 SSRF 通道；真实网络动作发生在 URLClassLoader 加载阶段。

**fd 缓存问题**：远程 jar 经 URLClassPath/JarFileFactory 缓存（refcount+close 控制器，见主报告 SRC-4 Info 对照），加载器生命周期内持有，非 SRC-4 缺陷。

## 4. 威胁场景与影响

- `useCodebaseOnly=false` 的旧配置（大量历史 RMI 应用/框架默认）下：攻击者向暴露的 RMI 端口投递带恶意 codebase 注解的序列化流 → 服务端从攻击者服务器下载类 → **RCE**（经典 RMI 远程类加载攻击，历史上需 SecurityManager 兜底，JDK 17 无 SM 后完全依赖开关）;
- 即使不加载类：codebase 拉取发起任意 HTTP 请求 → SSRF/内网探测;
- 本地 `java.rmi.server.codebase` 属性若被管理员配置为内网地址，所有 RMI 调用都会拉取——配置面投毒点。

## 5. 缓解与修复建议

- 保持 `useCodebaseOnly=true`（默认值）且不放开; 
- 暴露 RMI 服务时：RMI 注册表与业务端口防火墙隔离、调用方认证（如 JEP 290 序列化过滤器：`jdk.rmi` 相关 filter 配置）;
- 对 RMI 反序列化配置 `ObjectInputFilter`（对接报告 01）。

## 6. 审计结论

分级复核：**维持 Medium（开关门控型）**。默认配置安全（useCodebaseOnly=true）；降级配置（=false）或无 SM 环境放开后即为 High RCE 链。L776 的 URL 解析本身无校验是缺陷点，但被开关隔离。