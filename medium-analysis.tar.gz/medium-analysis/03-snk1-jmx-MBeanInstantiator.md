# 03. [Sink/SNK-1] Class.forName — com.sun.jmx.mbeanserver.MBeanInstantiator

| 项目 | 内容 |
|------|------|
| 规则 | SNK-1（Class.forName 反射加载 + 实例化） |
| 严重级别 | Medium（JMX 平台 by-design 能力，依赖 JMX 访问控制） |
| 位置 | `java.management/com/sun/jmx/mbeanserver/MBeanInstantiator.java:435`（`Class.forName(className, false, instance)`）、`647`（`Class.forName(className)`）；同族 L180/645/692（签名类解析） |
| 模块 | java.management |

## 1. 在 JDK 中的作用

`MBeanInstantiator` 是 JMX（Java 管理扩展）的**类实例化中枢**：JMX 规范要求 `MBeanServer.createMBean(className, ...)` 允许客户端按类名创建任意 MBean，本类负责把类名解析为 `Class` 并实例化：

- `findClass(className, loader)` → L647 `Class.forName(className)`（无 loader 时用本类加载器）;
- `instantiate(className, loaderName, ...)` → L435 `Class.forName(className, false, instance)`（指定的 ClassLoader MBean 提供的 loader）;
- 反序列化用 `ObjectInputStreamWithLoader`（L450-451，见该文件 L66 `Class.forName(name, false, loader)`）;
- 所有入参先过 `ReflectUtil.checkPackageAccess(className)`（L421/640）——但该检查**只在校验器存在的 SecurityManager 场景生效**，JDK 17 默认 SecurityManager 不可用，等于无类名限制。

调用路径：`MBeanServer.createMBean` → `DefaultMBeanServerInterceptor` → `MBeanInstantiator.instantiate`。

## 2. 使用方式（如何使用）

- 管理客户端（jmxremote/JConsole/自研监控）通过 `MBeanServerConnection.createMBean(String className, ObjectName name)` 创建任意类型 MBean（含远程 JMX 协议 `jmxrmi` 连接）;
- 已有 MBean 方法内调用 `MBeanServer.instantiate(className)` 动态创建临时对象;
- 动态 MBean（`RequiredModelMBean`/`StandardMBean`）解析操作签名类型时走 L180/692（`signature[i]` 也来自客户端参数）。

## 3. 触发条件分析（什么情况下触发）

**攻击面成立的条件**：

1. JVM 暴露了 JMX 远程监听（`com.sun.management.jmxremote.port` 或 RMI 注册表暴露），且认证/SSL 配置薄弱或凭据泄露——攻击者获得 JMX 会话；
2. 客户端以 `createMBean`/`instantiate` 提交任意类名（如 `javax.management.loading.MLet` 或业务类、或 classpath 中可静态初始化的类）;
3. 目标类能被 MBeanServer 可见的加载器找到（agent 加载器 / ClassLoaderRepository 中注册的 loader / 指定 loaderName 的 ClassLoader MBean）——远程 jar 加载需配合 MLet（见报告 09）;
4. 目标类构造器执行恶意逻辑（无参构造常见）。

**默认状态核实**：JDK 17 无 SecurityManager → `ReflectUtil.checkPackageAccess` 不拦截（该类在 `java.security` 移除 SM 后成为空操作路径）;JMX 远程默认**不开启**（需显式 port 配置），故默认不可达。

**fd 缓存问题**：本条不涉及文件句柄；若创建的是 MLet（URLClassLoader 子类），jar fd 由 URLClassPath/JarFileFactory 托管（有界+引用计数），属 by-design。

## 4. 威胁场景与影响

- 攻破/泄露 JMX 远程接口 → 任意类实例化 → 任意代码执行（JMX 是公认的 RCE 面：如 CVE-2016-3427、各类 JMX 反序列化绕过）;
- 无认证的 JMX 监听（`-Dcom.sun.management.jmxremote.authenticate=false`）是最常见误配，直接等同开放任意类加载。

## 5. 缓解与修复建议

- 绝不开放无认证 JMX 远程端口；生产环境关闭 `com.sun.management.jmxremote` 或仅 loopback + TLS + 强口令/证书;
- 不必需时禁用 `createMBean`（用 `StandardMBean` 白名单模式或自定义 `MBeanServer` 拦截器过滤 className）;
- 对 JMX 网段做防火墙隔离。

## 6. 审计结论

分级复核：**维持 Medium（条件触发型）**。JMX 平台规范设计如此，"任意类实例化"是特性而非缺陷，但暴露面管理不当即为 High；安全边界=JMX 访问控制。