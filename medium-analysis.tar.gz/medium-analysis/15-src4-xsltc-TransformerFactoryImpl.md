# 15. [Source/SRC-4] XSLTC translet 缓存 ZipFile 泄漏 — TransformerFactoryImpl.getBytecodesFromJar

| 项目 | 内容 |
|------|------|
| 规则 | SRC-4（ZipFile 打开后无任何关闭路径） |
| 严重级别 | Medium（半可信路径 + 每次调用泄漏 1 个 fd） |
| 位置 | `java.xml/com/sun/org/apache/xalan/internal/xsltc/trax/TransformerFactoryImpl.java:1490`（`jarFile = new ZipFile(file)`），方法 `getBytecodesFromJar`（L1455-1540） |
| 模块 | java.xml（XSLTC 编译器/转换器） |

## 1. 在 JDK 中的作用

XSLTC（`com.sun.org.apache.xalan.internal.xsltc`）是 JDK 内置 XSLT 编译器：把样式表编译成 translet Java 类。`TransformerFactoryImpl`（XSLTC 的 JAXP 外观）支持**预编译 translet 缓存**：

- 属性 `"auto-translet"`（L102 `AUTO_TRANSLET`，默认 false，setAttribute L440-446）开启"直接复用已编译 translet，跳过编译";
- 属性 `"jar-name"`（L100 `JAR_NAME`，setAttribute L426-429 写 `_jarFileName`）+ `"destination-directory"`（L98）决定 translet 字节码的 **jar 落盘位置**;
- `newTemplates(Source)`（L895-963）：`_autoTranslet && _jarFileName != null` → **`getBytecodesFromJar(source, transletClassName)`**（L939-940）从 jar 读字节码;若 jar 不存在（首次）则编译并把字节码连同 aux 类写入 jar（L1006-1041 区域 `BYTEARRAY_AND_JAR_OUTPUT`）;
- 未设置 jar-name 时走 `getBytecodesFromClasses`（L942，从 .class 文件/类经 loader 读，无此泄漏）。

**泄漏点**（L1488-1540 全方法核实）：`jarFile = new ZipFile(file)`（L1490）后：
- 遍历条目读字节码（L1504-1526，仅 `input.close()` 关闭条目流）;
- 所有返回路径（L1536 `return bytecodes`、L1539 `return null`、L1492-1494 IOException 提前返回）**均无 `jarFile.close()`**——**无 try-with-resources、无 finally**。每次调用恒定泄漏 1 个 zip 文件描述符。

## 2. 使用方式（如何使用）

```java
TransformerFactory tf = TransformerFactory.newInstance();
tf.setAttribute("auto-translet", "true");
tf.setAttribute("jar-name", "myTranslets.jar");   // translet 缓存 jar
tf.setAttribute("destination-directory", "/opt/xsltc-cache/");
Templates t = tf.newTemplates(xslSource);          // 每次调用 → getBytecodesFromJar → +1 fd
```

典型宿主：Web 应用把 XSLT 转换引擎配置为 XSLTC 并打开 translet jar 缓存（历史 Spring/内部平台常用）;`newTemplates` 常驻于每次请求级模板构建（或依赖模板缓存池周期性重建）。

## 3. 触发条件分析（什么情况下触发 fd 缓存/打开而不关闭）

**fd 打开而不关闭的确切条件**：

1. `_autoTranslet=true` 且 `_jarFileName != null`（两者缺一不可，L939 判定）;
2. 目标 jar 存在（首次编译后即存在）——后续每次 `newTemplates` 都打开新 `ZipFile`（**与 URLClassLoader 的 jar 缓存不同：这里是"每次调用新建实例"**，且零关闭路径）;
3. jar 路径（`_destinationDirectory + "/" + _jarFileName` 或 xsl 同目录）半可信：由应用配置决定;若可被外部影响（缓存目录可写/路径参数化），可放大为"按需制造新文件→新 fd"。

**泄漏速率**：1 fd / 次 newTemplates（命中 jar 分支）。典型 ulimit 1024 的容器：1024 次模板重建即耗尽 → 后续一切文件/网络/socket 打开失败 → **服务 DoS**。长周期进程（应用服务器常驻数月）即使低频调用也必然累积;GC 无法回收（ZipFile 无 Cleaner/finalizer 兜底关闭——`ZipFile` 本身有 finalizer，但本实例无引用持有方? 注意：`jarFile` 是局部变量，方法返回后成为垃圾 → **最终会被 GC 终结并关闭**——即"缓慢泄漏"而非"永久泄漏"：泄漏窗口 = 从打开到 GC 触发（不可控，可能很久，尤其 fd 压力下 GC 时机不定）。按 skill 分级仍为 Medium（缓慢泄漏，长期运行累积），若宿主频繁调用则加速。

**与正确写法对照**：同模块其他工具（`jdk.jlink` 的 JmodTask、`jdk.jartool` 系列）均为 try-with-resources（见主报告 Info 对照），本处是漏网。

## 4. 威胁场景与影响

- 转换引擎长时间运行 + 模板库频繁重建 → fd 缓慢爬升 → 达到 ulimit 后全进程 I/O 失败（包括新 HTTP 连接）→ DoS;
- 若 jar 路径可被攻击者写入/指定（缓存目录权限问题），攻击者上传同名/新 jar 文件并触发模板重建 → 加速 fd 消耗（每文件 1 fd）+ 文件中被读取的是 XSLTC 预期格式（读取面受限，注入字节码需配合 ClassLoader 面，不在本条）。

## 5. 缓解与修复建议

- **修复**：`getBytecodesFromJar` 改为 try-with-resources（`try (ZipFile jarFile = new ZipFile(file))`），两处 return 与异常路径全覆盖;
- 宿主侧：确认 XSLT 引擎是否用 XSLTC + auto-translet + jar-name;是则关闭 jar 缓存模式或改用 `getBytecodesFromClasses`（tools 类路径模式）;
- 模板对象缓存复用，避免频繁 `newTemplates`（本身也是性能问题）。

## 6. 审计结论

分级复核：**维持 Medium**。已逐行核实无关闭路径（L1490 开 → L1536/1539 返，无 finally/close）;泄漏为"GC 前不可控滞留"型，长期运行真实累积;路径半可信→按规则评为 Medium，不升 High（路径不直接外部可控）。属 JDK 内部少数真实资源管理缺陷，修复成本极低。