# 04. [Sink/SNK-1] Class.forName — javax.sql.rowset.spi.SyncFactory

| 项目 | 内容 |
|------|------|
| 规则 | SNK-1（Class.forName 反射加载 + newInstance） |
| 严重级别 | Medium（半可信配置/调用方输入） |
| 位置 | `java.sql.rowset/javax/sql/rowset/spi/SyncFactory.java:585`（`Class.forName(providerID, true, cl)` + L587 `c.newInstance()`） |
| 模块 | java.sql.rowset |

## 1. 在 JDK 中的作用

`SyncFactory` 是 RowSet 同步提供者（`SyncProvider`）的**注册表/工厂**：RowSet 需要与数据源同步数据时，按 `providerID`（字符串标识）找到实现类并实例化。注册来源（见同文件）：

- L289-295 `registerProvider(providerID)`：程序化注册;
- L346-385 初始化时读取属性文件：classpath 上的 `javax/sql/rowset.properties` 或 `-Drowset.properties=<path>` 指定的文件（`ROWSET_PROPERTIES`，L237/362-384）；
- `SyncFactory.getInstance(providerID)`（L549-593）：查注册表 → `ReflectUtil.checkPackageAccess(providerID)`（仅 SecurityManager 有效）→ **`Class.forName(providerID, true, TCCL).newInstance()`**（L585-587，`initialize=true`）。

调用方：`BaseRowSet.setSyncProvider(providerID)` / RowSet 实现（`com.sun.rowset` 系列）在执行 `execute()` 前获取 provider。

## 2. 使用方式（如何使用）

- 应用配置 `rowset.properties` 声明自定义同步器类名，或代码 `SyncFactory.getInstance("com.example.MySyncProvider")`;
- RowSet：`rowset.setSyncProvider("com.example.MySyncProvider")` → 同步操作时经 `SyncFactory.getInstance` 实例化。

## 3. 触发条件分析（什么情况下触发）

**反射加载攻击面成立的场景**：

1. `providerID` 来自**可被攻击者影响的调用方**：`setSyncProvider(String)` 直接接受字符串——若应用把用户输入传给它（少见但存在），类名任意可控;
2. `rowset.properties` 所处位置可被篡改：classpath 会被部署环境控制；`-Drowset.properties=` 指向用户可写路径时更直接;
3. classpath 包含可利用类（静态初始化/无参构造执行逻辑）。

**默认状态**：属性文件不存在时注册表为空，`getInstance` 返回默认 `RIOptimisticProvider`（L563）——默认不触发远程/任意加载；唯一执行点 L585 需 providerID 已注册或直接传入。

**fd 缓存问题**：本条不涉及文件句柄。

## 4. 威胁场景与影响

- 配置投毒（rowset.properties 被篡改或 -D 参数被改写）→ 启动/首次同步时 `Class.forName(配置类名, true, TCCL)` 加载任意类 → 静态块执行 → RCE（配置面攻击）;
- 若应用把用户输入透传 `setSyncProvider` → 直接任意类加载（该类场景更接近 High，但 RowSet API 使用者极少如此使用，按半可信评估）。

## 5. 缓解与修复建议

- `rowset.properties` 所在路径与 classpath 权限收紧（不可被降权用户写）;
- 禁止把外部输入直接用作 `setSyncProvider`/`getInstance` 参数;
- 需要时给 `SyncFactory` 注册表做 providerID 白名单校验。

## 6. 审计结论

分级复核：**维持 Medium（配置/调用方半可信来源）**。默认配置下不可达；触发需配置文件投毒或调用方透传——均为间接条件。若审计对象存在"用户输入 → setSyncProvider"直连场景，应升级为 High。