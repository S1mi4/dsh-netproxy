# 02. [Sink/SNK-1] Class.forName — com.sun.jndi.ldap.VersionHelper.loadClass

| 项目 | 内容 |
|------|------|
| 规则 | SNK-1（Class.forName 反射加载） |
| 严重级别 | Medium（受默认关闭的信任开关保护） |
| 位置 | `java.naming/com/sun/jndi/ldap/VersionHelper.java:108-110`（配套：同文件 L94-106 getURLClassLoader、L129-135 getUrlArray） |
| 模块 | java.naming |

## 1. 在 JDK 中的作用

`VersionHelper` 是 LDAP JNDI provider（`com.sun.jndi.ldap`）的辅助类，封装"用哪个类加载器/如何加载类"的决策。它的两个方法构成 **JNDI LDAP 远程对象解析** 的核心：

- `getURLClassLoader(String[] url)`（L94-106）：把 LDAP 条目 `javaCodebase` 属性中的 URL 列表构造成 `URLClassLoader`——仅当系统属性 `com.sun.jndi.ldap.object.trustURLCodebase=true`（**默认 false**，见 L52-64 static 块）;
- `loadClass(String className)`（L108-110）：`Class.forName(className, true, getContextClassLoader())`——**注意 `initialize=true`，加载即执行静态初始化块**。类名来自 LDAP 目录属性，无任何白名单。

调用方（`com.sun.jndi.ldap.Obj`）：
- `decodeObject`（L227-264）：应用 `InitialContext.lookup` 命中 LDAP 对象的入口；
  - `javaSerializedData` 属性 → `deserializeObject`（L235-240，先查 `isSerialDataAllowed()` 即 `trustSerialData`，默认 false 直接拒绝）;
  - `javaRemoteLocation` 属性 → `decodeRmiObject`（L241-249，同样先查 trustSerialData）;
  - Reference 对象（`javaReferenceAddress`）→ `decodeReference`（L256）；
- `decodeReference`（L380-508）：L413 `getURLClassLoader(codebases)` 构造 codebase 加载器（**未查 trustURLCodebase 之外的条件——门控在 getURLClassLoader 内部**）；二进制 RefAddr 反序列化前查 `isSerialDataAllowed`（L475）;
- `deserializeObject`（L533-544）：用 `LoaderInputStream`（L617-634，内部类）反序列化——其 `resolveClass` 走 `classLoader.loadClass(desc.getName())`（L630），代理接口走 `Class.forName(interfaces[i], false, classLoader)`（L644）。

## 2. 使用方式（如何使用）

应用通过 JNDI 标准 API 使用：`new InitialContext().lookup("ldap://host/entry")` 或 `DirContext` 查询。当 LDAP 条目含有 `javaClassName`/`javaCodeBase`/`javaSerializedData`/`javaReferenceAddress`/`javaRemoteLocation`/`javaFactory` 等 `java*` 属性（RMI-IIOP/LDAP 对象编码约定），provider 即按上述流程**把 LDAP 数据还原为 Java 对象**。思科/历史攻击中该机制被用于"从 LDAP 目录任意加载类"。

## 3. 触发条件分析（什么情况下触发）

**`loadClass` 的远程加载生效需要（多项缺一不可）**：

1. 应用确实通过 JNDI 解析了**攻击者可写入条目的 LDAP 源**（未认证的内网 LDAP、攻击者搭的假 LDAP、应用配置的 LDAP 被指向恶意目录）——应用侧信任边界决定；
2. 信任开关被显式打开：
   - `com.sun.jndi.ldap.object.trustURLCodebase=true`（远程 codebase 类加载，旧版默认 true，**JDK 17 默认 false**）→ `getURLClassLoader` 才会用 LDAP 的 `javaCodebase` URL 建加载器；
   - `com.sun.jndi.ldap.object.trustSerialData=true`（**默认 false**）→ `javaSerializedData`/`javaRemoteLocation`/二进制 RefAddr 反序列化分支才放行；
3. 目标类（或 codebase URL 指向的 jar 中的类）不在本机 classpath → 才需要远程加载；
4. 攻击者提供的恶意类需能**静态初始化/构造时执行**（`initialize=true` 放大此风险：`Class.forName(className, true, ...)` 加载即执行 static 块）。

**fd 缓存问题**：本条不直接持有 fd。但它创建的 `URLClassLoader`（getURLClassLoader）会按需打开远程/本地的 jar（`URLJarFile`→`JarFileFactory` 缓存，见主报告 SRC-4 Info 对照），fd 生命周期=加载器生命周期，属 by-design 有界缓存；真正的资源面是"远程类加载"而非 fd。

## 4. 威胁场景与影响

- 应用向不可信 LDAP 做 JNDI 解析（典型：解析攻击者可控的 LDAP 条目，或应用把 LDAP 服务器地址配成攻击者服务器）→ `javaCodebase` 指向攻击者 http 服务器 → `URLClassLoader` 拉取恶意 jar → `loadClass`/LoaderInputStream 加载 → **RCE（经典 JNDI 注入链，本 jndi-lab 场景即此）**；
- 即使不信任远程 codebase，`trustSerialData=true` 时 `javaSerializedData` 也可触发反序列化 gadget（与报告 01 联动）。

## 5. 缓解与修复建议

- 保持两个 `trust*` 属性默认值（false）不变；生产环境显式 `-Dcom.sun.jndi.ldap.object.trustURLCodebase=false -Dcom.sun.jndi.ldap.object.trustSerialData=false`；
- LDAP 服务端做 TLS 与端标识校验（`ldaps`/`com.sun.jndi.ldap.connect.timeout` 等），目录条目视为半可信；
- 应用侧对 JNDI lookup 结果做类型白名单，禁止任意 Object 还原。

## 6. 审计结论

分级复核：**维持 Medium（默认开关保护下的高风险链）**。默认配置下（两开关 false）本次 audit 的 jdk-src 版本不可直接利用；一旦信任开关被打开（旧配置迁移、管理员误开），本条即升级为 High 且可达 RCE——属于"配置门控型"攻击面。