# 10. [Source/SRC-3] JNDI LDAP javaCodebase → URLClassLoader（SSRF + 远程类加载）— VersionHelper.getURLClassLoader

| 项目 | 内容 |
|------|------|
| 规则 | SRC-3（URL 列表 → URLClassLoader 远程拉取，SSRF/远程类加载） |
| 严重级别 | Medium（受 trustURLCodebase 默认关闭保护） |
| 位置 | `java.naming/com/sun/jndi/ldap/VersionHelper.java:94-106`（`URLClassLoader.newInstance(getUrlArray(url), parent)`）、`129-135`（`new URL(url[i])`）；联动 `com/sun/jndi/ldap/Obj.java:239,413`（decodeObject/decodeReference 取 codebase 调用点） |
| 模块 | java.naming |

## 1. 在 JDK 中的作用

与报告 02 同一条攻击链的**URL 侧**：LDAP 目录条目可用 `javaCodebase` 属性携带一个空格分隔的 URL 列表，JNDI provider 据此构造 `URLClassLoader`，用于加载 `javaClassName` 指定的类或反序列化所需类。`getURLClassLoader(String[] url)`：

- `trustURLCodebase`（`com.sun.jndi.ldap.object.trustURLCodebase`，**默认 false**，本文件 L52-57 static 初始化）为 true 时 → `URLClassLoader.newInstance(urls, TCCL)`——URL **无协议/主机白名单**，`http`、`file`、`jar` 等任意 scheme;
- false 时返回 parent（TCCL）——远程加载完全关闭;
- `getUrlArray`（L129-135）逐个 `new URL(url[i])`（MalformedURLException 上抛）。

调用点（Obj.java）：
- `decodeObject` L239：`javaSerializedData` 反序列化前的加载器（还要求 trustSerialData=true，否则 L236-238 先行拒绝）;
- `decodeReference` L413：Reference 的 factory 类加载器（**该调用不查 trustSerialData，仅依赖 getURLClassLoader 内部的 trustURLCodebase 门控**）;
- 加载动作发生时（URLClassLoader.findClass → URLClassPath → `openConnection().getInputStream()`，见 `URLClassPath.java:554,621,652`）即发起对 codebase URL 的真实请求。

## 2. 使用方式（如何使用）

- 应用 JNDI `lookup`/`list` 解析 LDAP 条目（对象类 `javaContainer`/`javaObject`/`javaNamingReference` 等）→ provider 自动尝试还原 Java 对象 → 需要类时按 codebase 加载;
- 典型服务型用法（应用服务器把 RMI/LDAP 对象存入目录供客户端下载 stub/工厂类）。

## 3. 触发条件分析（什么情况下触发）

**远程拉取（SSRF + 类加载）成立的条件（全部满足）**：

1. `com.sun.jndi.ldap.object.trustURLCodebase=true`（显式 -D 设置；JDK 17 默认 false——本文件 L56 默认值核实）;
2. 目录条目 `javaCodebase` 可被攻击者写入/指向恶意服务器（未认证 LDAP、应用解析不可信目录源）;
3. 应用随后实际加载该条目引用的类（Reference factory 创建、或 javaSerializedData 配合 trustSerialData）——触发真实拉取;
4. 类不存在于本机 classpath（否则用 TCCL，不请求 codebase）。

**默认状态**：trustURLCodebase=false → `getURLClassLoader` 恒返回 TCCL → URL 数组即使被构造也只是解析（`new URL` 不联网），远程拉取被阻断——默认不可利用。

**fd 缓存问题**：`URLClassLoader` 拉到的 jar 进入 `URLClassPath.JarLoader`/`JarFileFactory` 缓存（fd 与加载器同生命周期，关闭路径存在，见主报告 SRC-4 Info 对照）；注入多 URL 会对应产生多缓存条目，但受 refcount/close 约束，非 SRC-4 缺陷。

## 4. 威胁场景与影响

- 与报告 02 构成 JNDI LDAP 注入完整链：`trustURLCodebase=true` + 不可信目录 → codebase 指向攻击者 HTTP 服务器 → 恶意 jar 下载 → 远程类执行 → **RCE**;
- codebase 指向内网地址时（类加载失败也会先发请求）→ **SSRF/内网探测通道**;
- 这是 2021-2023 年大量 log4j 类 JNDI 注入事件的核心机制（本 jndi-lab 即围绕其复现）。

## 5. 缓解与修复建议

- 保持 `trustURLCodebase=false`（强制）：应用启动参数固化;
- 同一开关体系内同时保持 `trustSerialData=false`（报告 02）;
- 不可信 LDAP 源使用 `ldaps` + 端标识校验；目录条目视为攻击面;
- 出站防火墙限制应用对任意 HTTP 拉取（缓解 SSRF 面）。

## 6. 审计结论

分级复核：**维持 Medium（开关门控型，触发即 High）**。源码级事实（无协议/主机白名单 + 依赖管理员开关）确认；默认配置下本次 jdk-src 不可直接利用。与报告 02 合并处置：两个 trust 开关 + LDAP 来源信任边界 = 该攻击面的全部控制点。