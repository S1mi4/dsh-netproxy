# 16. [Source/SRC-4] 潜在 JarFile fd 泄漏 — javax.xml.catalog.Util.isFileUriExist

| 项目 | 内容 |
|------|------|
| 规则 | SRC-4（JarFile 打开不关闭）——**当前版本不可达（潜在缺陷）** |
| 严重级别 | Medium（代码存在泄漏缺陷；本版本无触发调用方，实为潜在项） |
| 位置 | `java.xml/javax/xml/catalog/Util.java:197`（`JarFile jf = new JarFile(jarFile);`），方法 `isFileUriExist(URI, boolean)`（L176-213） |
| 模块 | java.xml（OASIS XML Catalog 工具） |

## 1. 在 JDK 中的作用

`Util.isFileUriExist(URI uri, boolean openJarFile)` 是 catalog 模块的**资源存在性检查**辅助方法：

- `isFileUri(uri)`（L160）→ 仅 `file:` scheme;
- `isFileUriExist(uri, false)`：`file:` → `new File(path).isFile()`;`jar:` → **直接返回 true（不打开）**;
- `isFileUriExist(uri, true)`：`jar:` 分支（L193-204）→ **`new JarFile(jarFile)`**（L197）→ `getJarEntry(entryName)` 判断条目存在 → **方法结束，无任何 close**（无 try-with-resources/无 finally;异常路径 L202-204 同样不关）;
- 唯一调用方：`GroupEntry.verifyCatalogFile(catalogURI)`（L515-533，JDK 17 中 L521-524 调用时 `openJarFile` 参数为 **`false`**）——catalog 文件加载时的存在性校验。

## 2. 使用方式（如何使用）

- catalog 链加载时对每个 `nextCatalog`/子 catalog 的 URI 做存在性检查（`verifyCatalogFile` → L522）;
- `openJarFile=true` 的语义（javadoc L172-175）：针对 `jar:file:...!/entry` 形态的 catalog URI 检查"jar 内条目是否存在"——为更严格的校验而设计，但**JDK 17 无调用者**（全树 grep `isFileUriExist` 仅 Util 定义 + GroupEntry 一处 false 调用，见审计证据）。

## 3. 触发条件分析（什么情况下触发 fd 缓存/打开而不关闭）

**严格结论（逐条核实）**：

1. `new JarFile(jarFile)`（L197）仅在 `openJarFile==true` 时执行——**本版本（17.0.19）没有任何调用方传 true**（实测 grep：唯一调用点 `GroupEntry.java:522` 传 `false`）;
2. 因此**当前 JDK 17.0.19 的运行时行为中，本泄漏不可达**——catalog 加载不会打开 JarFile;
3. 若未来版本/上游补丁新增 `openJarFile=true` 的调用（或应用通过同包扩展/反射调用该 package-private 方法——受限），则每次对 `jar:` catalog URI 的存在性检查泄漏 1 个 JarFile fd;jar 路径来自 catalog 文件内容（半可信）;
4. 泄漏形态同报告 15：JarFile 内部经 ZipFile（有 Cleaner 兜底），GC 前滞留不可控 → 缓慢泄漏;频繁解析 + jar: 条目多 → 加速。

**与第 15 条的区别**：15 是可达缺陷（默认行为泄漏），本条是不可达缺陷（代码缺陷存在，触发通道缺失）——按 skill 分级仍列 Medium 以提示代码级问题，但实际影响评估为"潜在"。

## 4. 威胁场景与影响

- 当前版本：无实际影响（不可达）;
- 潜在影响（若被激活）：catalog 频繁加载（每次文档解析重载 catalog 的宿主）→ jar: URI 检查 → fd 滞留 → 长时运行 DoS;
- 修复价值：一行 try-with-resources，消除回归风险。

## 5. 缓解与修复建议

- **修复**：`Util.isFileUriExist` 的 jar: 分支改为 `try (JarFile jf = new JarFile(jarFile)) { ... }`;异常路径由 try-with-resources 覆盖;
- 宿主侧无需动作（不可达）；若自建 catalog 体系，避免使用 jar: 形态 catalog URI（可改用 file: 直接目录）。

## 6. 审计结论

分级复核：**维持 Medium（潜在、当前不可达）**。源码缺陷客观存在（L197 打开 → 无关闭路径），但调用面缺失使实际风险为 0——报告如实标注"潜在缺陷"，避免误报的同时提醒修复。作为对照：`JarIndex.parseJars`（`java.base/jdk/internal/util/jar/JarIndex.java:217-244`）同类打开但正确 `zrf.close()`，是安全写法参照。