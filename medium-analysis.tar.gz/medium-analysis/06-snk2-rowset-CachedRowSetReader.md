# 06. [Sink/SNK-2] JDBC 连接 — com.sun.rowset.internal.CachedRowSetReader.connect

| 项目 | 内容 |
|------|------|
| 规则 | SNK-2（DriverManager.getConnection 动态 JDBC URL） |
| 严重级别 | Medium（与 05 同源：RowSet URL 属性） |
| 位置 | `java.sql.rowset/com/sun/rowset/internal/CachedRowSetReader.java:340`（`DriverManager.getConnection(((RowSet)caller).getUrl(), ...)`） |
| 模块 | java.sql.rowset |

## 1. 在 JDK 中的作用

`CachedRowSetReader` 是 `CachedRowSet`/`WebRowSet` 等**离线 RowSet** 的"数据读取器"：RowSet 需要从数据库把数据读入内存缓存时调用它。`connect(RowSetInternal caller)`（L304-347）是连接协商的核心：

- 调用方已注入 Connection → 直接复用（`userCon=true`，L307-312）;
- 调用方 `getDataSourceName()` 非空 → JNDI lookup 取 DataSource（L314-337，JNDI 注入面，范围外）;
- 调用方 `getUrl()` 非空 → **`DriverManager.getConnection(url, username, password)`**（L340-342）。

入口：`CachedRowSetReader.readData`（`execute()` 的内部路径）→ `connect`。与 05 的区别：这里的 URL 来自**任意 RowSet 实现**（`RowSetInternal` 接口），覆盖面比 JdbcRowSetImpl 更广——包括 `CachedRowSetImpl`、`WebRowSetImpl`、`FilteredRowSetImpl` 等全部 com.sun.rowset 家族，且多为长生命周期缓存组件（可跨会话传递/序列化存储）。

## 2. 使用方式（如何使用）

- 应用：`CachedRowSetImpl crs = new CachedRowSetImpl(); crs.setUrl(...); crs.execute();`（execute → readData → connect）;
- RowSet 在线程间传递、存入 HttpSession、或作为序列化数据在集群/缓存间搬运——属性随对象移动。

## 3. 触发条件分析（什么情况下触发）

与报告 05 的三条件一致，但触发面更宽：

1. 任何 `RowSetInternal` 类型对象的 `url` 属性被外部影响（反序列化覆盖、Session 注入、应用误配）;
2. 对象上发生 `execute()`（或 `readData` 间接路径）——Cached 家族常由定时同步/启动加载任务自动执行，触发无需用户交互;
3. classpath 含攻击者 URL 所需 JDBC 驱动（同 05 载荷清单：autoDeserialize/H2 INIT/PG socketFactory/任意端口探测）。

**额外的放大因素**：CachedRowSet 数据可经 `writeXml`/序列化被持久化并重新 `readXml`/反序列化——攻击者构造的 `WebRowSet XML 或 Java 序列化` 被服务端加载后，`execute` 即建连。历史上 WebRowSet XML 反序列化（CVE-2019-2692 等）即属此类。

**fd 缓存问题**：本条不涉及文件句柄；连接关闭由 RowSet 使用方负责（`close` 约定）。

## 4. 威胁场景与影响

- 反序列化/XML 加载攻击面：投递恶意 RowSet 对象 → 触发 `execute` → JDBC 连接攻击者指定端点 → RCE（恶意驱动特性）/SSRF/内网探测;
- 应用把 RowSet 作为 Session/缓存对象存储时，对象生命周期长、触发点分散，防御盲区更大。

## 5. 缓解与修复建议

- 同 05：反序列化过滤器必须放行/阻断名单覆盖 `com.sun.rowset.*`（建议直接阻断）;
- WebRowSet XML 输入视为不可信，禁止向 `readXml`/`readXml` 族方法喂外部数据;
- JDBC URL 白名单 + 出站防火墙。

## 6. 审计结论

分级复核：**维持 Medium**。与 05 同源同判：正常 API 用法无害；在"不可信对象进入 RowSet 执行链"场景下实际危害 High。两处 getConnection 一并处置（`JdbcRowSetImpl:642` 与 `CachedRowSetReader:340`）即可覆盖 com.sun.rowset 全家族。